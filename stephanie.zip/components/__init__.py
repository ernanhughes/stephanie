# stephanie/components/__init__.py
from stephanie.components.lats_component import LATSComponent
