# stephanie/memory/prompt_store.py
from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from typing import Optional

from sqlalchemy import text
from sqlalchemy.dialects.postgresql import dialect

from stephanie.memory.base_store import BaseSQLAlchemyStore
from stephanie.models.goal import GoalORM
from stephanie.models.prompt import PromptORM


class PromptStore(BaseSQLAlchemyStore):
    orm_model = PromptORM
    default_order_by = PromptORM.timestamp.desc()

    def __init__(self, session_or_maker, logger=None):
        super().__init__(session_or_maker, logger)
        self.name = "prompts"

    def name(self) -> str:
        return self.name

    # --------------------
    # GOALS
    # --------------------
    def get_or_create_goal(
        self,
        goal_text: str,
        goal_type: str = None,
        focus_area: str = None,
        strategy: str = None,
        source: str = "user",
    ) -> GoalORM:
        def op(s):
            
            goal = s.query(GoalORM).filter_by(goal_text=goal_text).first()
            if not goal:
                goal = GoalORM(
                    goal_text=goal_text,
                    goal_type=goal_type,
                    focus_area=focus_area,
                    strategy=strategy,
                    llm_suggested_strategy=None,
                    source=source,
                )
                s.add(goal)
                s.flush()
                if self.logger:
                    self.logger.log("GoalCreated", {
                        "goal_id": goal.id,
                        "goal_text": goal_text[:100],
                        "source": source,
                    })
            return goal
        return self._run(op)

    # --------------------
    # BASIC CRUD
    # --------------------
    def get_by_id(self, prompt_id: int) -> Optional[PromptORM]:
        return self._run(lambda: self._scope().get(PromptORM, prompt_id))

    def save(
        self,
        goal: dict,
        agent_name: str,
        prompt_key: str,
        prompt_text: str,
        response: Optional[str] = None,
        strategy: str = "default",
        pipeline_run_id: Optional[int] = None,
        extra_data: dict = None,
        version: int = 1,
    ) -> int:
        def op(s):
            
            goal_text = goal.get("goal_text", "")
            goal_type = goal.get("goal_type")
            goal_orm = self.get_or_create_goal(goal_text=goal_text, goal_type=goal_type)

            # deactivate previous
            s.query(PromptORM).filter_by(
                agent_name=agent_name, prompt_key=prompt_key
            ).update({"is_current": False})

            db_prompt = PromptORM(
                goal_id=goal_orm.id,
                pipeline_run_id=pipeline_run_id,
                agent_name=agent_name,
                prompt_key=prompt_key,
                prompt_text=prompt_text,
                response_text=response,
                strategy=strategy,
                version=version,
                extra_data=json.dumps(extra_data or {}),
            )
            s.add(db_prompt)
            s.flush()

            if self.logger:
                self.logger.log("PromptStored", {
                    "id": db_prompt.id,
                    "text": prompt_text[:30],
                    "agent": agent_name,
                    "length": len(prompt_text),
                })
            return db_prompt.id
        return self._run(op)

    # --------------------
    # LOOKUPS
    # --------------------
    def get_from_text(self, prompt_text: str) -> Optional[PromptORM]:
        def op(s):
            
            prompt = (
                s.query(PromptORM)
                .filter(PromptORM.prompt_text == prompt_text)
                .order_by(PromptORM.timestamp.desc())
                .first()
            )
            if self.logger:
                self.logger.log("PromptLookup", {
                    "matched": bool(prompt),
                    "text_snippet": prompt_text[:100],
                })
            return prompt
        return self._run(op)

    def get_id_from_response(self, response_text: str) -> Optional[int]:
        def op(s):
            
            prompt = (
                s.query(PromptORM)
                .filter(PromptORM.response_text == response_text)
                .order_by(PromptORM.timestamp.desc())
                .first()
            )
            if self.logger:
                self.logger.log("PromptLookup", {
                    "matched": bool(prompt),
                    "text_snippet": response_text[:100],
                })
            return prompt.id if prompt else None
        return self._run(op)

    def find_matching(self, agent_name: str, prompt_text: str, strategy: str = None):
        def op(s):
            
            query = s.query(PromptORM).filter_by(agent_name=agent_name, prompt_text=prompt_text)
            if strategy:
                query = query.filter_by(strategy=strategy)
            return [p.to_dict() for p in query.limit(10).all()]
        return self._run(op)

    def find_similar_prompt(
        self, agent_name: str, prompt_text: str, strategy: str = None, similarity_threshold: float = 0.7
    ):
        def normalize(text): return re.sub(r"\s+", " ", text.strip().lower())
        text_a = normalize(prompt_text or "")

        def op(s):
            
            query = s.query(PromptORM).filter(
                PromptORM.agent_name == agent_name,
                PromptORM.response_text.isnot(None),
                PromptORM.response_text != "",
            )
            if strategy:
                query = query.filter_by(strategy=strategy)

            candidates = query.limit(100).all()
            if not strategy:
                return [p.to_dict() for p in candidates]

            matches = []
            for p in candidates:
                text_b = normalize(p.prompt_text or "")
                if not text_a or not text_b:
                    continue
                similarity = SequenceMatcher(None, text_a, text_b).ratio()
                if similarity >= similarity_threshold:
                    matches.append((similarity, p))
            matches.sort(reverse=True, key=lambda x: x[0])
            return [p.to_dict() for _, p in matches]
        return self._run(op)

    # --------------------
    # TRAINING
    # --------------------
    def get_prompt_training_set(self, goal: str, limit: int = 500) -> list[dict]:
        def op(s):
            
            sql = text("""
                SELECT 
                    p.id,
                    g.goal_text AS goal,
                    p.prompt_text,
                    p.prompt_key,
                    p.timestamp,
                    h.text AS hypothesis_text,
                    h.elo_rating,
                    h.review
                FROM goals g
                JOIN prompts p ON p.goal_id = g.id
                JOIN hypotheses h ON h.prompt_id = p.id AND h.goal_id = g.id
                WHERE g.goal_text = :goal
                AND h.enabled = TRUE
                ORDER BY p.id, h.elo_rating DESC, h.updated_at DESC
                LIMIT :limit
            """)
            result = s.execute(sql, {"goal": goal, "limit": limit})
            return [
                {
                    "id": row[0],
                    "goal": row[1],
                    "prompt_text": row[2],
                    "prompt_key": row[3],
                    "timestamp": row[4],
                    "hypothesis_text": row[5],
                    "elo_rating": row[6],
                    "review": row[7],
                }
                for row in result.fetchall()
            ]
        return self._run(op)

    # --------------------
    # PIPELINE
    # --------------------
    def get_by_run_id(self, run_id: int) -> list[dict]:
        def op(s):
            
            prompts = s.query(PromptORM).filter(PromptORM.pipeline_run_id == run_id).all()
            return [p.to_dict() for p in prompts]
        return self._run(op)
