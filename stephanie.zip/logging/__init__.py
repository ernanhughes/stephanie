# stephanie/logs/__init__.py
"""Main logger for app"""

from .icons import get_event_icon
from .json_logger import JSONLogger
