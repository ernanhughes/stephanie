# stephanie/components/nexus/encoder/vision.py
from __future__ import annotations
