# stephanie/components/nexus/encoder/text.py
from __future__ import annotations
