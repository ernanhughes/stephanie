"""
Parser Utilities for SSP Components

This module provides robust parsing functions for handling LLM responses
in the SSP system, with special attention to the proposer's output format.
"""

import re
from typing import Any, Dict, List, Optional, Pattern


# Regular expression to match key-value pairs in proposer responses
_LINE_RE: Pattern = re.compile(
    r'^\s*"?(?P<key>[A-Za-z_]+)"?\s*[:=]\s*(?P<value>.+?)\s*,?\s*$'
)

def _clean_text(val: str) -> str:
    """
    Clean text values by removing surrounding quotes and extra whitespace.
    
    Handles various quote types and ensures clean text output.
    
    Args:
        val: Input string to clean
        
    Returns:
        Cleaned string with quotes removed and whitespace trimmed
    """
    s = val.strip()
    if len(s) >= 2:
        # Check for matching quote pairs
        quote_pairs = [
            ('"', '"'),
            ("'", "'"),
            ("“", "”"),
            ("‘", "’")
        ]
        
        for open_quote, close_quote in quote_pairs:
            if s.startswith(open_quote) and s.endswith(close_quote):
                s = s[1:-1].strip()
                break
                
    return s

def _int_in(val: str) -> Optional[int]:
    """
    Extract integer value from a string.
    
    Args:
        val: Input string that may contain an integer
        
    Returns:
        Integer value if found and valid, None otherwise
    """
    m = re.search(r"(-?\d+)", val)
    if not m:
        return None
    
    try:
        return int(m.group(1))
    except Exception:
        return None

def _bool_in(val: str) -> Optional[bool]:
    """
    Extract boolean value from a string.
    
    Args:
        val: Input string that may represent a boolean
        
    Returns:
        Boolean value if recognized, None otherwise
    """
    val_lower = val.lower().strip()
    if val_lower in ("true", "yes", "1", "on"):
        return True
    elif val_lower in ("false", "no", "0", "off"):
        return False
    return None

def parse_proposer_lines(text: str) -> Dict[str, Any]:
    """
    Parse the proposer's LLM response into structured data.
    
    The proposer is expected to output lines in the format:
    key: value
    
    Where keys are: rationale, difficulty, verifiability, question
    
    This function is robust to:
    - Variations in whitespace
    - Different quote styles
    - Extra text before/after the key-value pairs
    - Case variations in keys
    
    Args:
        text: Raw LLM response from the proposer
        
    Returns:
        Dictionary with parsed values:
        - rationale: str (explanation for the question)
        - difficulty: int (0-100 scale)
        - verifiability: int (0-100 scale)
        - question: str (the generated question)
        - raw: str (original response)
        - ok: bool (whether parsing was successful)
    """
    raw = (text or " ").strip()
    out: Dict[str, Any] = {
        "rationale": "",
        "difficulty": 0,
        "verifiability": 0,
        "question": "",
        "raw": raw,
        "ok": False,
    }
    
    if not raw:
        return out
    
    # Process lines in reverse to handle multi-line values
    lines = [line.strip() for line in raw.splitlines() if line.strip()]
    found_keys = set()
    
    # First pass: identify key-value pairs
    for line in lines:
        match = _LINE_RE.match(line)
        if match:
            key = match.group("key").lower()
            value = match.group("value")
            
            if key == "rationale":
                out["rationale"] = _clean_text(value)
                found_keys.add("rationale")
            elif key == "difficulty":
                difficulty = _int_in(value)
                if difficulty is not None:
                    out["difficulty"] = max(0, min(100, difficulty))  # Clamp to 0-100
                    found_keys.add("difficulty")
            elif key == "verifiability":
                verifiability = _int_in(value)
                if verifiability is not None:
                    out["verifiability"] = max(0, min(100, verifiability))  # Clamp to 0-100
                    found_keys.add("verifiability")
            elif key == "question":
                out["question"] = _clean_text(value)
                found_keys.add("question")
    
    # Second pass: handle multi-line values if needed
    if "rationale" in found_keys and not out["rationale"]:
        # If rationale was identified but empty, check for multi-line rationale
        rationale_lines = []
        capturing = False
        
        for line in lines:
            if line.lower().startswith("rationale:"):
                capturing = True
                # Extract value after "rationale:"
                value = line[len("rationale:"):].strip()
                if value:
                    rationale_lines.append(_clean_text(value))
                continue
                
            if capturing:
                # Stop capturing when we hit the next known key
                if any(line.lower().startswith(f"{key}:") for key in 
                      ["difficulty", "verifiability", "question"]):
                    break
                rationale_lines.append(line)
        
        if rationale_lines:
            out["rationale"] = " ".join(rationale_lines).strip()
    
    # Validation - all required fields must be present
    required_keys = {"rationale", "difficulty", "verifiability", "question"}
    out["ok"] = required_keys.issubset(found_keys) and bool(out["question"].strip())
    
    return out

def parse_verifier_lines(text: str) -> Dict[str, Any]:
    """
    Parse the verifier's LLM response into structured data.
    
    Args:
        text: Raw LLM response from the verifier
        
    Returns:
        Dictionary with parsed values:
        - answer: str (predicted answer)
        - rationale: str (explanation for the answer)
        - score: float (verification score)
        - raw: str (original response)
        - ok: bool (whether parsing was successful)
    """
    raw = (text or " ").strip()
    out: Dict[str, Any] = {
        "answer": "",
        "rationale": "",
        "score": 0.0,
        "raw": raw,
        "ok": False,
    }
    
    if not raw:
        return out
    
    # Process lines to find key-value pairs
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
            
        # Look for answer line
        if line.lower().startswith("answer:"):
            out["answer"] = _clean_text(line[7:].strip())
        
        # Look for rationale line
        elif line.lower().startswith("rationale:"):
            out["rationale"] = _clean_text(line[10:].strip())
    
    # Determine if parsing was successful
    out["ok"] = bool(out["answer"].strip()) and bool(out["rationale"].strip())
    
    return out

def parse_solution_search_lines(text: str, top_k: int = 3) -> List[str]:
    """
    Parse the solution search LLM response into a list of evidence snippets.
    
    Args:
        text: Raw LLM response from solution search
        top_k: Number of expected snippets
        
    Returns:
        List of evidence snippets (up to top_k)
    """
    raw = (text or " ").strip()
    snippets = []
    
    if not raw:
        return snippets
    
    # Look for "snippet:" prefixes
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
            
        # Handle lines starting with "snippet:"
        if line.lower().startswith("snippet:"):
            snippet = _clean_text(line[8:].strip())
            if snippet:
                snippets.append(snippet)
    
    # If no "snippet:" prefixes found, try to split by line numbers or bullet points
    if not snippets:
        # Look for numbered lines (1., 2., etc.)
        numbered_lines = re.findall(r"^\s*\d+\.\s+(.+)$", raw, re.MULTILINE)
        if numbered_lines:
            snippets = [_clean_text(line) for line in numbered_lines[:top_k]]
        
        # Look for bullet points
        elif not snippets:
            bullet_lines = re.findall(r"^\s*[-*•]\s+(.+)$", raw, re.MULTILINE)
            if bullet_lines:
                snippets = [_clean_text(line) for line in bullet_lines[:top_k]]
    
    # If still no snippets, try to split into reasonable chunks
    if not snippets:
        # Split by sentence boundaries if it looks like a paragraph
        if len(raw.split()) > 10 and "." in raw:
            sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", raw) if s.strip()]
            snippets = sentences[:top_k]
    
    return snippets[:top_k]  # Ensure we don't return more than top_k snippets