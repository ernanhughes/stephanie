"""
Episode Trace Data Structure

This module defines the EpisodeTrace class that captures the
complete state of an SSP episode, including all critical
information needed for self-play rewards and VPM visualization.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class EpisodeTrace:
    """Complete trace of an SSP episode for analysis and visualization."""
    
    episode_id: str
    seed_answer: str
    question: str
    proposer_evidence: List[str]
    predicted_answer: str
    evidence_docs: List[str]
    verified: bool
    verifier_score: float
    solver_steps: int
    difficulty: float = 0.0
    proposer_meta: Dict[str, Any] = field(default_factory=dict)
    verifier_meta: Dict[str, Any] = field(default_factory=dict)
    solver_meta: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    episode_duration: float = 0.0
    proposer_reward: Optional[float] = None
    solver_reward: Optional[float] = None