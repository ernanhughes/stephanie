# stephanie/components/ssp/agent.py
from __future__ import annotations

import logging
from typing import Any, Dict

from stephanie.agents.base_agent import BaseAgent
from stephanie.components.ssp.services.state_service import StateService
from stephanie.components.ssp.services.vpm_control_service import VPMControlService
from stephanie.components.ssp.services.vpm_visualization_service import VPMVisualizationService
from stephanie.components.ssp.training.trainer import Trainer


from stephanie.utils.progress_mixin import ProgressMixin

_logger = logging.getLogger(__name__)


class SSPAgent(BaseAgent, ProgressMixin):

    def __init__(self, cfg: Dict[str, Any], memory, container, logger):
        super().__init__(cfg, memory, container, logger)
        self.seeds = cfg.get("seeds", [])

        container.register(
            name="ssp_state",
            factory=lambda: StateService(cfg=cfg, memory=memory, container=container, logger=logger),
            dependencies=[],
            init_args={
            },
        )

        container.register(
            name="vpm_control_service",
            factory=lambda: VPMControlService(cfg=cfg, memory=memory, container=container, logger=logger),
            dependencies=[],
            init_args={
            },
        )

        # in SSPAgent.__init__
        container.register(
            name="ssp_vpm_viz",
            factory=lambda: VPMVisualizationService(cfg=cfg, memory=memory, logger=logger, container=container),
            dependencies=[],
            init_args={}
        )



    async def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute one step of the Self-Play loop within the given pipeline context.

        This is the main entry point called by the Stephanie pipeline. It:
        1. Logs the start of the SSP episode
        2. Runs a single `train_step` through the Trainer
        3. Handles errors gracefully with structured logging
        4. Attaches results under `context['ssp']` for downstream consumption

        Args:
            context: Pipeline execution context. May contain:
                - pipeline_run_id: Unique identifier for this pipeline run
                - Additional metadata or constraints to guide proposal generation

        Returns:
            The input `context` dictionary updated with SSP results under `context['ssp']`.
            The structure is:
            {
                "ssp": {
                    "episode_id": str,           # Unique ID for this SSP cycle
                    "success": bool,             # Whether the solution passed verification
                    "metrics": dict,             # Detailed performance and state metrics
                    "training_batch": dict|null  # Batch data for RL training (if GRPO enabled)
                }
            }

        Raises:
            RuntimeError: If the trainer fails catastrophically.
            Any exception from underlying components (Proposer, Solver, ScoringService).

        Logs:
            - "SSPStepStarted": When the training step begins
            - "SSPStepCompleted": On successful completion with outcome and metrics
            - "SSPStepFailed": If an error occurs during the step
        """
        run_id = context.get("pipeline_run_id", "unknown")
        try:
            _logger.info(f"SSP step started for run_id={run_id}")

            trainer = Trainer(self.cfg, self.memory, self.container, self.logger)
            self._init_progress(self.container, _logger)
            task = f"SSP:{run_id}"
            total_steps = 1  # Example fixed step count; adjust as needed
            self.pstart(task=task, total=total_steps, meta={"run_id": run_id})

            stats = await trainer.run_batch(seeds=self.seeds, context=context)

            self.pstage(task=task, stage="complete")
            self.pdone(task=task)

            print("== Summary ==", stats)

            # Attach the result to the context under the standard key
            context[self.output_key] = stats

            return context

        except Exception as e:
            # Critical failure; log details and re-raise
            error_msg = f"SSP step failed for run_id={run_id}: {str(e)}"
            _logger.exception(error_msg)  # Also logs traceback at ERROR level
            raise RuntimeError(error_msg) from e