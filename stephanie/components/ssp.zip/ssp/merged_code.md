<!-- Merged Python Code Files -->


## File: __init__.py

`python
# stephanie/components/ssp/__init__.py
from __future__ import annotations

``n

## File: agent.py

`python
# stephanie/components/ssp/agent.py
from __future__ import annotations

import logging
from typing import Any, Dict

from stephanie.agents.base_agent import BaseAgent
from stephanie.components.ssp.services.state_service import StateService
from stephanie.components.ssp.services.vpm_control_service import VPMControlService
from stephanie.components.ssp.services.vpm_visualization_service import VPMVisualizationService
from stephanie.components.ssp.training.trainer import Trainer


from stephanie.utils.progress_mixin import ProgressMixin

_logger = logging.getLogger(__name__)


class SSPAgent(BaseAgent, ProgressMixin):

    def __init__(self, cfg: Dict[str, Any], memory, container, logger):
        super().__init__(cfg, memory, container, logger)
        self.seeds = cfg.get("seeds", [])

        container.register(
            name="ssp_state",
            factory=lambda: StateService(cfg=cfg, memory=memory, container=container, logger=logger),
            dependencies=[],
            init_args={
            },
        )

        container.register(
            name="vpm_control_service",
            factory=lambda: VPMControlService(cfg=cfg, memory=memory, container=container, logger=logger),
            dependencies=[],
            init_args={
            },
        )

        # in SSPAgent.__init__
        container.register(
            name="ssp_vpm_viz",
            factory=lambda: VPMVisualizationService(cfg=cfg, memory=memory, logger=logger, container=container),
            dependencies=[],
            init_args={}
        )



    async def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute one step of the Self-Play loop within the given pipeline context.

        This is the main entry point called by the Stephanie pipeline. It:
        1. Logs the start of the SSP episode
        2. Runs a single `train_step` through the Trainer
        3. Handles errors gracefully with structured logging
        4. Attaches results under `context['ssp']` for downstream consumption

        Args:
            context: Pipeline execution context. May contain:
                - pipeline_run_id: Unique identifier for this pipeline run
                - Additional metadata or constraints to guide proposal generation

        Returns:
            The input `context` dictionary updated with SSP results under `context['ssp']`.
            The structure is:
            {
                "ssp": {
                    "episode_id": str,           # Unique ID for this SSP cycle
                    "success": bool,             # Whether the solution passed verification
                    "metrics": dict,             # Detailed performance and state metrics
                    "training_batch": dict|null  # Batch data for RL training (if GRPO enabled)
                }
            }

        Raises:
            RuntimeError: If the trainer fails catastrophically.
            Any exception from underlying components (Proposer, Solver, ScoringService).

        Logs:
            - "SSPStepStarted": When the training step begins
            - "SSPStepCompleted": On successful completion with outcome and metrics
            - "SSPStepFailed": If an error occurs during the step
        """
        run_id = context.get("pipeline_run_id", "unknown")
        try:
            _logger.info(f"SSP step started for run_id={run_id}")

            trainer = Trainer(self.cfg, self.memory, self.container, self.logger)
            self._init_progress(self.container, _logger)
            task = f"SSP:{run_id}"
            total_steps = 1  # Example fixed step count; adjust as needed
            self.pstart(task=task, total=total_steps, meta={"run_id": run_id})

            stats = await trainer.run_batch(seeds=self.seeds, context=context)

            self.pstage(task=task, stage="complete")
            self.pdone(task=task)

            print("== Summary ==", stats)

            # Attach the result to the context under the standard key
            context[self.output_key] = stats

            return context

        except Exception as e:
            # Critical failure; log details and re-raise
            error_msg = f"SSP step failed for run_id={run_id}: {str(e)}"
            _logger.exception(error_msg)  # Also logs traceback at ERROR level
            raise RuntimeError(error_msg) from e
``n

## File: cli.py

`python
from __future__ import annotations

if __name__ == "__main__":
    # Minimal smoke test with three seeds (serve as ground truths)
    from stephanie.components.ssp.training.trainer import Trainer

    seeds = [
        "permafrost thaw releasing methane increases radiative forcing",
        "insulin enables glucose uptake in muscle and adipose tissue",
        "backpropagation updates weights by gradient descent on loss",
    ]

    stats = Trainer(difficulty=0.3, verify_threshold=0.6).run_batch(seeds)
    print("== Summary ==", stats)


# ───────────────────────────────────────────────────────────────────────────────
# configs/self_play_mvp.yaml  (optional; if you’re using Hydra)
# ───────────────────────────────────────────────────────────────────────────────
# defaults:
#   - _self_
#
# self_play_mvp:
#   difficulty: 0.3
#   verify_threshold: 0.6
#   solver:
#     max_depth: 2
#     beam_width: 3
#   proposer:
#     prompt: "Given <answer>{answer}</answer>, generate ONE challenging, verifiable question wrapped in <question> tags."
#
# # Later: wire real model + search + verifier here
# model:
#   router: stephanie.models.ModelRouter
# retriever:
#   kind: memcube
# verifier:
#   kind: hrm_mars
``n

## File: core\__init__.py

`python
# stephanie/components/ssp/core/__init__.py
from __future__ import annotations
``n

## File: core\algorithm.py

`python
# stephanie/components/ssp/core/algorithm.py
"""
Main SSP (Self-Play System) Algorithm

This module implements the complete SSP algorithm as described in the paper,
coordinating the interaction between Proposer, Solver, and Verifier components.
"""
from __future__ import annotations

import asyncio
import time
import datetime
import uuid
from typing import Any, Dict, List, Optional

from stephanie.components.ssp.core.roles.proposer import Proposer 
from stephanie.components.ssp.core.roles.solver import Solver 
from stephanie.components.ssp.core.roles.verifier import Verifier

from stephanie.components.ssp.core.protocols import EpisodeContext, SSPMetrics
from stephanie.components.ssp.utils.trace import EpisodeTrace
from stephanie.components.ssp.training.rewards import (
    calculate_self_play_rewards,
    update_episode_with_rewards
)
from stephanie.components.ssp.services.vpm_visualization_service import VPMVisualizationService


class SSPAlgorithm:
    """
    Implementation of the SSP algorithm that coordinates the interaction
    between Proposer, Solver, and Verifier components.
    
    This implements the full SSP loop:
    1. Proposer generates a question from a seed answer WITH EVIDENCE GATHERING
    2. Verifier applies rule-based filters and RAG-gated verification
    3. If verified, Solver performs deep search to answer the question
    4. Rewards are calculated for both Proposer and Solver
    5. Components may be updated based on the rewards
    """
    
    def __init__(
        self,
        proposer: Proposer,
        solver: Solver,
        verifier: Verifier,
        vpm_visualization: Optional[VPMVisualizationService] = None,
        **kwargs
    ):
        """
        Initialize the SSP algorithm with concrete component implementations.
        
        Args:
            proposer: Proposer implementation
            solver: Solver implementation
            verifier: Verifier implementation
            vpm_visualization: VPM visualization service
            **kwargs: Additional configuration parameters
        """
        self.proposer = proposer
        self.solver = solver
        self.verifier = verifier
        self.vpm_visualization = vpm_visualization
        self.metrics = SSPMetrics()
        self.episode_history = []
    
    async def run_episode(
        self,
        seed_answer: str,
        context: Optional[EpisodeContext] = None
    ) -> EpisodeTrace:
        """
        Run a single SSP episode starting from a seed answer.
        
        Args:
            seed_answer: Ground truth answer to build a question around
            context: Additional context for the episode
            
        Returns:
            EpisodeTrace containing the full episode data
        """
        episode_id = f"ssp-{int(time.time()*1000)}-{uuid.uuid4().hex[:6]}"
        start_time = time.time()
        
        try:
            # 1. Proposer generates question WITH EVIDENCE GATHERING
            question, proposer_evidence, proposer_meta = await self.proposer.propose(
                seed_answer, 
                context=context
            )
            
            # 2. Verifier applies rule-based filters and RAG-gated verification
            verification_result = await self.verifier.verify(
                question,
                seed_answer,
                proposer_evidence,
                context=context
            )
            
            # 3. If verified, Solver performs deep search
            predicted_answer = ""
            evidence_docs = []
            solver_steps = 0
            solver_meta = {}
            
            if verification_result.is_valid:
                predicted_answer, evidence_docs, solver_steps, solver_meta = await self.solver.solve(
                    question,
                    seed_answer,
                    context=context,
                    use_search=True
                )
            
            # 4. Create episode trace
            episode = EpisodeTrace(
                episode_id=episode_id,
                seed_answer=seed_answer,
                question=question,
                proposer_evidence=proposer_evidence,
                predicted_answer=predicted_answer,
                evidence_docs=evidence_docs,
                verified=verification_result.is_valid,
                verifier_score=verification_result.score,
                solver_steps=solver_steps,
                difficulty=proposer_meta.get("difficulty", 0.5),
                proposer_meta=proposer_meta,
                verifier_meta={
                    "reason": verification_result.reason,
                    "filter_results": verification_result.filter_results,
                    **verification_result.verification_details
                },
                solver_meta=solver_meta
            )
            
            # 5. Calculate rewards
            self._calculate_and_apply_rewards([episode], 0)
            
            # 6. Update metrics
            self._update_metrics(episode)
            
            # 7. Generate VPM visualization if service is available
            if self.vpm_visualization:
                self.vpm_visualization.generate_episode_visualization(
                    unit=episode_id,
                    episode=episode
                )
            
            # 8. Record episode duration
            episode.episode_duration = time.time() - start_time
            
            return episode
            
        except Exception as e:
            self.metrics.total_episodes += 1
            self.metrics.verification_pass_rate = self.metrics.verified_episodes / max(self.metrics.total_episodes, 1)
            
            # Return error episode
            return EpisodeTrace(
                episode_id=episode_id,
                seed_answer=seed_answer,
                question="",
                proposer_evidence=[],
                predicted_answer="",
                evidence_docs=[],
                verified=False,
                verifier_score=0.0,
                solver_steps=0,
                difficulty=0.0,
                proposer_meta={"error": str(e)},
                verifier_meta={"error": str(e)},
                solver_meta={"error": str(e)}
            )
    
    async def train_step(
        self,
        seed_answers: List[str],
        context: Optional[EpisodeContext] = None
    ) -> Dict[str, Any]:
        """
        Run a training step with multiple seed answers.
        
        Args:
            seed_answers: List of ground truth answers to process
            context: Additional context for the training step
            
        Returns:
            Dictionary of training metrics and results
        """
        verified_episodes = []
        unverified_count = 0
        
        # Run episodes in parallel
        tasks = [self.run_episode(seed, context) for seed in seed_answers]
        episodes = await asyncio.gather(*tasks)
        
        # Process results
        for episode in episodes:
            if episode.verified:
                verified_episodes.append(episode)
            else:
                unverified_count += 1
        
        # Calculate rewards
        rewards = calculate_self_play_rewards(verified_episodes, unverified_count)
        
        # Store episodes for potential training updates
        self.episode_history.extend(episodes)
        
        # Return metrics
        return {
            **rewards,
            "total_episodes": len(episodes),
            "verified_count": len(verified_episodes),
            "unverified_count": unverified_count,
            "metrics": self.get_metrics().__dict__
        }
    
    def _calculate_and_apply_rewards(
        self,
        verified_episodes: List[EpisodeTrace],
        unverified_count: int
    ) -> None:
        """Calculate and apply rewards to episodes."""
        rewards = calculate_self_play_rewards(verified_episodes, unverified_count)
        
        for episode in verified_episodes:
            update_episode_with_rewards(
                episode,
                rewards["solver_reward"],
                rewards["proposer_reward"]
            )
    
    def _update_metrics(self, episode: EpisodeTrace) -> None:
        """Update system metrics based on episode outcome."""
        self.metrics.total_episodes += 1
        
        if episode.verified:
            self.metrics.verified_episodes += 1
            
            # Update proposer metrics
            self.metrics.proposer_success_rate = self.metrics.verified_episodes / self.metrics.total_episodes
            self.metrics.avg_question_difficulty = (
                (self.metrics.avg_question_difficulty * (self.metrics.verified_episodes - 1) + episode.difficulty) 
                / self.metrics.verified_episodes
            )
            
            # Update solver metrics
            self.metrics.solver_accuracy = (
                (self.metrics.solver_accuracy * (self.metrics.verified_episodes - 1) + (1.0 if episode.predicted_answer == episode.seed_answer else 0.0)) 
                / self.metrics.verified_episodes
            )
            self.metrics.avg_solver_steps = (
                (self.metrics.avg_solver_steps * (self.metrics.verified_episodes - 1) + episode.solver_steps) 
                / self.metrics.verified_episodes
            )
            
            # Update verification metrics
            self.metrics.verification_pass_rate = self.metrics.verified_episodes / self.metrics.total_episodes
            self.metrics.avg_verification_score = (
                (self.metrics.avg_verification_score * (self.metrics.verified_episodes - 1) + episode.verifier_score) 
                / self.metrics.verified_episodes
            )
        
        # Update self-play metrics
        if episode.proposer_reward is not None and episode.solver_reward is not None:
            self.metrics.proposer_adversarial_reward = (
                (self.metrics.proposer_adversarial_reward * (self.metrics.total_episodes - 1) + episode.proposer_reward) 
                / self.metrics.total_episodes
            )
            self.metrics.solver_cooperative_reward = (
                (self.metrics.solver_cooperative_reward * (self.metrics.total_episodes - 1) + episode.solver_reward) 
                / self.metrics.total_episodes
            )
        
        # Update curriculum difficulty
        self.metrics.curriculum_difficulty = (
            self.metrics.curriculum_difficulty * 0.9 + 
            episode.difficulty * 0.1
        )
        
        self.metrics.last_updated = datetime.now()
    
    def get_metrics(self) -> SSPMetrics:
        """
        Get current performance metrics for the SSP system.
        
        Returns:
            SSPMetrics object with current system metrics
        """
        return self.metrics
    
    def reset(self) -> None:
        """
        Reset the algorithm state (for fresh training runs).
        """
        self.metrics = SSPMetrics()
        self.episode_history = []
    
    def is_initialized(self) -> bool:
        """
        Check if the algorithm has been properly initialized.
        
        Returns:
            True if initialized, False otherwise
        """
        return all([
            self.proposer is not None,
            self.solver is not None,
            self.verifier is not None
        ])
``n

## File: core\node.py

`python
# stephanie/components/ssp/core/node.py
"""
Node Data Structure for SSP Tree Search

This module defines the canonical Node class used throughout the SSP system.
The Node represents a state in the search tree used by the ATSSolver and other
components that perform tree-based search.

The structure is designed to be compatible with TreeEventEmitter for telemetry
and progress tracking.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

@dataclass
class Node:
    """
    Represents a node in the search tree used by SSP components.
    
    This is the canonical definition used throughout the SSP system.
    """
    # Basic identification
    id: str
    parent_id: Optional[str]
    root_id: str
    
    # Tree structure
    depth: int
    sibling_index: int
    node_type: str  # 'root' | 'rewrite' | other node types
    
    # Content
    query: str
    score: float
    context: str
    
    # Optional extended properties
    task_description: Optional[str] = None
    summary: Optional[str] = None
    metric: Optional[float] = None
    is_buggy: Optional[bool] = None
    meta: Dict[str, Any] = None
    
    def __post_init__(self):
        """Initialize default values for optional fields."""
        if self.meta is None:
            self.meta = {}
``n

## File: core\protocols.py

`python
# stephanie/components/ssp/core/protocols.py
"""
SSP Protocol Definitions

Shared data structures, type aliases, and protocols used across the SSP system.
These interfaces let you swap implementations (LLM vs MemCube, ATS vs mock, etc.)
without touching the algorithmic core.

Key components:
- EpisodeContext: Context propagated through an SSP episode
- EpisodeResult / VerificationResult / JudgeResult
- SSPMetrics (system-level KPIs)
- Core roles: Proposer, Retriever, Verifier, Solver, Judge
- Services: PromptService, ProgressReporter, EventSink, ArtifactStore, VPMEncoder
- Filters/Rewards/Curriculum protocols
- SSPAlgorithm (orchestrator façade)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import (
    Any,
    Dict,
    List,
    Optional,
    Protocol,
    TypedDict,
    Iterable,
    Sequence,
    Tuple,
    runtime_checkable,
)

# ---------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------
EpisodeID = str
Question = str
Answer = str
Snippet = str
Score = float
Difficulty = float


# ---------------------------------------------------------------------
# Episode context and results
# ---------------------------------------------------------------------
class EpisodeContext(TypedDict, total=False):
    """Context passed through the SSP pipeline."""
    pipeline_run_id: str
    session_id: str
    user_id: Optional[str]
    timestamp: float
    metadata: Dict[str, Any]
    # Optional knobs commonly needed
    max_tokens: int
    temperature: float
    top_p: float


@dataclass
class VerificationResult:
    """Result of the verification process."""
    is_valid: bool
    score: float
    reason: str
    filter_results: Dict[str, bool]
    verification_details: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class JudgeResult:
    """Compact judge output used across verification/evaluation."""
    score: int                     # 0..100, integer for rubric parity
    rationale: str
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EpisodeResult:
    """Complete result of an SSP episode."""
    episode_id: EpisodeID
    seed_answer: Answer
    question: Question
    predicted_answer: Answer
    evidence_docs: List[Snippet]
    proposer_evidence: List[Snippet]
    verified: bool
    verifier_score: float
    solver_steps: int
    difficulty: Difficulty
    proposer_meta: Dict[str, Any]
    verifier_meta: Dict[str, Any]
    solver_meta: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.now)
    episode_duration: float = 0.0


@dataclass
class SSPMetrics:
    """Performance metrics for the SSP system."""
    # Episode metrics
    total_episodes: int = 0
    verified_episodes: int = 0
    success_rate: float = 0.0

    # Proposer metrics
    proposer_success_rate: float = 0.0
    avg_question_difficulty: float = 0.0
    evidence_quality: float = 0.0

    # Solver metrics
    solver_accuracy: float = 0.0
    avg_solver_steps: float = 0.0
    evidence_coverage: float = 0.0

    # Verification metrics
    verification_pass_rate: float = 0.0
    avg_verification_score: float = 0.0

    # Self-play metrics
    proposer_adversarial_reward: float = 0.0
    solver_cooperative_reward: float = 0.0
    curriculum_difficulty: float = 0.0

    # Timestamps
    last_updated: datetime = field(default_factory=datetime.now)


# ---------------------------------------------------------------------
# Core role protocols (paper-faithful)
# ---------------------------------------------------------------------
@runtime_checkable
class Proposer(Protocol):
    """
    Searching proposer: crafts a single question from a seed mechanism (answer),
    optionally collecting evidence O(τ) while proposing.
    Returns: (question, meta, evidence_snippets)
    """
    async def propose(self, seed_answer: Answer, context: EpisodeContext) -> Tuple[Question, Dict[str, Any], List[Snippet]]: ...


@runtime_checkable
class Retriever(Protocol):
    """
    Retrieval bridge. History-first, MemCube, web, or LLM-backed—your choice.
    """
    async def retrieve(self, query: str, seed_answer: Answer, context: EpisodeContext, k: int) -> List[Snippet]: ...


@runtime_checkable
class Verifier(Protocol):
    """
    RAG-gated verification (no-search solver): decide if question is valid and solvable
    using only proposer-provided evidence; implements rejection sampling.
    """
    async def verify(self, question: Question, seed_answer: Answer, evidence: Sequence[Snippet], context: EpisodeContext) -> VerificationResult: ...


@runtime_checkable
class Solver(Protocol):
    """
    Deep search solver (e.g., ATS) that can use full retrieval.
    Returns: (predicted_answer, evidence_snippets, steps, meta)
    """
    async def solve(self, question: Question, context: EpisodeContext) -> Tuple[Answer, List[Snippet], int, Dict[str, Any]]: ...


@runtime_checkable
class Judge(Protocol):
    """
    Knowledge judge used within verification/eval. Must obey the strict two-line format elsewhere,
    but here we return a structured object.
    """
    async def judge(self, goal_text: str, user_text: str, assistant_text: str, evidence: Sequence[Snippet], context: EpisodeContext) -> JudgeResult: ...


# ---------------------------------------------------------------------
# Services / infrastructure
# ---------------------------------------------------------------------
@runtime_checkable
class PromptService(Protocol):
    """
    LLM prompt runner used by proposer/verifier/retriever.
    """
    async def run_prompt(self, prompt: str, context: Dict[str, Any]) -> str: ...


@runtime_checkable
class ProgressReporter(Protocol):
    """
    Mirrors ProgressMixin methods so components can report stages/ticks.
    """
    def start(self, task: str, **kw: Any) -> None: ...
    def stage(self, task: str, stage: str, **kw: Any) -> None: ...
    def set(self, task: str, done: int, total: int, **kw: Any) -> None: ...
    def end(self, task: str, **kw: Any) -> None: ...


@runtime_checkable
class EventSink(Protocol):
    """
    Minimal event sink (TreeEventEmitter-compatible).
    """
    def emit(self, event: str, payload: Dict[str, Any]) -> None: ...


@runtime_checkable
class ArtifactStore(Protocol):
    """
    Episode/run artifact persistence (JSON, text, images).
    """
    def save_json(self, path: str, obj: Dict[str, Any]) -> str: ...
    def save_text(self, path: str, text: str) -> str: ...
    def save_image(self, path: str, data: bytes, *, format: Optional[str] = None) -> str: ...


@runtime_checkable
class VPMEncoder(Protocol):
    """
    Encodes per-episode metrics into a VPM artifact (PNG/JSON).
    Returns the artifact path.
    """
    def encode(self, episode_id: EpisodeID, node_scores: List[float], judge_score: int, evidence_snippets: List[str]) -> str: ...


# ---------------------------------------------------------------------
# Filters / curriculum / rewards
# ---------------------------------------------------------------------
@runtime_checkable
class RuleFilter(Protocol):
    """
    Rule-based pre-verification checks (format, leakage, min length, tool-use, etc.).
    Returns per-rule boolean flags.
    """
    def apply(self, question: Question, seed_answer: Answer, evidence: Sequence[Snippet], context: EpisodeContext) -> Dict[str, bool]: ...


class EpisodeTracker(Protocol):
    """Tracks episode state across the pipeline."""
    def start_episode(self, episode_id: EpisodeID, seed_answer: Answer) -> None: ...
    def update_episode(self, episode_id: EpisodeID, **kwargs: Any) -> None: ...
    def complete_episode(self, episode_id: EpisodeID, result: EpisodeResult) -> None: ...
    def get_episode(self, episode_id: EpisodeID) -> Optional[EpisodeResult]: ...


class RewardCalculator(Protocol):
    """Computes proposer/solver rewards over verified episodes."""
    def calculate_rewards(self, verified_episodes: List[EpisodeResult]) -> Dict[str, float]: ...
    def get_reward_history(self) -> List[Dict[str, float]]: ...


class CurriculumManager(Protocol):
    """Manages difficulty progression."""
    def update_curriculum(self, success: bool, difficulty: Difficulty) -> Difficulty: ...
    def get_current_difficulty(self) -> Difficulty: ...
    def reset_curriculum(self) -> None: ...


# ---------------------------------------------------------------------
# Algorithm façade
# ---------------------------------------------------------------------
@runtime_checkable
class SSPAlgorithm(Protocol):
    """
    High-level orchestrator interface so your agent/trainer can be swapped out.
    """
    async def run_episode(self, seed_answer: Answer, context: EpisodeContext) -> EpisodeResult: ...
    async def run_batch(self, seeds: Iterable[Answer], context: EpisodeContext, *, concurrency: int = 1) -> SSPMetrics: ...


``n

## File: core\roles\proposer.py

`python
# stephanie/components/ssp/core/roles/proposer.py
"""
Proposer Role Interface

The Proposer is responsible for generating questions from seed answers.
In the SSP methodology, the Proposer:
- Takes a ground truth answer (seed)
- Performs retrieval to gather evidence WHILE crafting the question
- Returns both the question and the evidence gathered
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple

from stephanie.components.ssp.core.protocols import EpisodeContext


class Proposer(ABC):
    """
    Abstract interface for the Proposer component in SSP.
    
    The Proposer generates questions from seed answers WITH EVIDENCE GATHERING.
    This is the "searching proposer" described in the paper.
    """
    
    @abstractmethod
    async def propose(
        self,
        seed_answer: str,
        context: Optional[EpisodeContext] = None
    ) -> Tuple[str, List[str], Dict[str, Any]]:
        """
        Generate a question from a seed answer WITH EVIDENCE GATHERING.
        
        Args:
            seed_answer: Ground truth answer to build a question around
            context: Additional context for the proposal
            
        Returns:
            Tuple of (question, evidence_snippets, metadata) where:
            - evidence_snippets: Evidence gathered DURING question creation
            - metadata should include difficulty, etc.
        """
        pass
    
    @abstractmethod
    def get_capabilities(self) -> Dict[str, Any]:
        """
        Return information about the Proposer's capabilities.
        
        Returns:
            Dictionary describing capabilities like:
            - supports_search_during_proposal: bool (should be True)
            - max_evidence_snippets: int
        """
        pass
``n

## File: core\roles\solver.py

`python
# stephanie/components/ssp/core/roles/solver.py
"""
Solver Role Interface

The Solver is responsible for answering questions using deep search.
In the SSP methodology, the Solver has TWO MODES:
1. Verification mode: answers using ONLY the proposer's evidence (NO SEARCH)
2. Deep search mode: performs full search to find the best answer
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple

from stephanie.components.ssp.core.protocols import EpisodeContext


class Solver(ABC):
    """
    Abstract interface for the Solver component in SSP.
    
    The Solver answers questions using various search strategies.
    It operates in two modes:
    1. Verification mode: answers using ONLY the proposer's evidence (no search)
    2. Deep search mode: performs full search to find the best answer
    """
    
    @abstractmethod
    async def solve(
        self,
        question: str,
        seed_answer: str,
        context: Optional[EpisodeContext] = None,
        use_search: bool = True,
        evidence_snippets: Optional[List[str]] = None
    ) -> Tuple[str, List[str], int, Dict[str, Any]]:
        """
        Solve a question using the appropriate search strategy.
        
        Args:
            question: Question to answer
            seed_answer: Ground truth answer (for search guidance)
            context: Additional context for solving
            use_search: Whether to perform search (False for verification mode)
            evidence_snippets: Optional evidence to use (for verification mode)
            
        Returns:
            Tuple of (predicted_answer, evidence_used, steps_taken, metadata)
        """
        pass
    
    @abstractmethod
    async def verify_answer(
        self,
        question: str,
        seed_answer: str,
        evidence_snippets: List[str]
    ) -> VerificationResult:
        """
        Verify an answer using ONLY the provided evidence (no search).
        
        This implements the RAG-gated verification step from the paper.
        
        Args:
            question: Question to answer
            seed_answer: Ground truth answer to verify against
            evidence_snippets: Evidence gathered by the Proposer
            
        Returns:
            VerificationResult object with verification outcome
        """
        pass
    
    @abstractmethod
    def get_capabilities(self) -> Dict[str, Any]:
        """
        Return information about the Solver's capabilities.
        
        Returns:
            Dictionary describing capabilities like:
            - supports_verification_mode: bool
            - max_search_depth: int
        """
        pass
``n

## File: core\roles\verifier.py

`python
# stephanie/components/ssp/core/roles/verifier.py
"""
Verifier Role Interface

The Verifier is responsible for filtering questions before they
proceed to deep search. In the SSP methodology, the Verifier:
- Applies rule-based filters to questions
- Runs the RAG-gated verification (using Solver in no-search mode)
- Determines if a question should be accepted or rejected
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple

from stephanie.components.ssp.core.protocols import EpisodeContext


class Verifier(ABC):
    """
    Abstract interface for the Verifier component in SSP.
    
    The Verifier filters questions before they proceed to deep search.
    It implements the critical RAG-gated verification step from the paper.
    """
    
    @abstractmethod
    def apply_filters(
        self,
        question: str,
        evidence_snippets: List[str],
        seed_answer: str
    ) -> Tuple[bool, List[str]]:
        """
        Apply rule-based filters to a question.
        
        Args:
            question: Question to filter
            evidence_snippets: Evidence gathered by the Proposer
            seed_answer: Ground truth answer
            
        Returns:
            Tuple of (is_valid, list_of_failed_rules)
        """
        pass
    
    @abstractmethod
    async def verify(
        self,
        question: str,
        seed_answer: str,
        evidence_snippets: List[str],
        context: Optional[EpisodeContext] = None
    ) -> VerificationResult:
        """
        Verify a question meets all criteria for deep search.
        
        This implements the paper's RAG-gated verification:
        1. Apply rule-based filters
        2. Run verification using Solver with ONLY proposer's evidence
        3. Determine if question should be accepted
        
        Args:
            question: Question to verify
            seed_answer: Ground truth answer
            evidence_snippets: Evidence gathered by the Proposer
            context: Additional context for verification
            
        Returns:
            VerificationResult object with verification outcome
        """
        pass
    
    @abstractmethod
    def get_filter_rules(self) -> List[Dict[str, Any]]:
        """
        Return the current filter rules configuration.
        
        Returns:
            List of filter rule definitions
        """
        pass
    
    @abstractmethod
    def get_verification_threshold(self) -> float:
        """
        Return the current verification score threshold.
        
        Returns:
            Threshold value (0-1)
        """
        pass
``n

## File: impl\__init__.py

`python
# stephanie/components/ssp/impl/__init__.py
from __future__ import annotations

``n

## File: impl\proposers\searching_proposer.py

`python
"""
Searching Proposer Implementation

This implementation adds the critical "search while proposing" capability
described in the SSP paper. The proposer actively gathers evidence while
crafting the question, which is then used in the RAG-gated verification.
"""

import asyncio
import re
from typing import Any, Dict, List, Optional, Tuple
import time

from stephanie.components.ssp.core.roles.proposer import Proposer
from stephanie.components.ssp.core.protocols import EpisodeContext
from stephanie.components.ssp.utils.parser import parse_proposer_lines
from stephanie.prompts.prompt_loader import PromptLoader
import logging


PROPOSER_PROMPT = """
SYSTEM:
You are building an SSP dataset. Given the canonical mechanism (SEED_ANSWER), write ONE precise, verifiable question whose correct answer is that mechanism.

SEED_ANSWER:
{{ answer }}

CONSTRAINTS:
- Ask for the mechanism directly (no trivia, no multi-part).
- Be specific and test factual understanding.
- No explanations or extra lines.

OUTPUT FORMAT — WRITE EXACTLY FOUR LINES, IN THIS ORDER, NO CODE FENCES:
rationale: <1–2 sentences on why this question targets the mechanism>
difficulty: <integer 0-100>
verifiability: <integer 0-100>
question: <the single best question>
"""

_logger = logging.getLogger(__name__)

class SearchingProposer(Proposer):
    """
    Proposer implementation that gathers evidence WHILE crafting questions.
    
    This implements the "searching proposer" from the SSP paper:
    1. Takes a seed answer
    2. Generates query rewrites
    3. Performs retrieval for each rewrite
    4. Crafts a question using the gathered evidence
    5. Returns both question and evidence
    """
    
    def __init__(
        self,
        cfg: Dict[str, Any],
        memory: Any,
        container: Any,
        logger: Any,
        solution_search
    ):
        """
        Initialize the SearchingProposer.
        
        Args:
            cfg: Configuration dictionary
            memory: Memory tool
            container: Dependency container
            logger: Logger instance
            solution_search: Optional pre-configured SolutionSearch instance
        """
        self.cfg = cfg
        self.memory = memory
        self.container = container
        self.logger = logger
        self._prompt_name = cfg.get("proposer", {}).get("prompt_name", "proposer")
        self._prompt_text = cfg.get("proposer", {}).get("prompt_text")
        self._backoff = cfg.get("proposer", {}).get("backoff_sec", 0.5)
        self.retries = cfg.get("proposer", {}).get("retries", 2)
        
        # Get solution search for evidence gathering
        self.solution_search = solution_search
        if not self.solution_search:
            raise ValueError("SolutionSearch is required for evidence gathering")
            
        # Get VPM control service for decision making
        self.vpm_control = container.get("vpm_control_service")
        self.prompt_loader = PromptLoader(memory=self.memory, logger=self.logger)
        self.prompt_service = container.get("prompt")

        # Configuration parameters
        self.rewrites = cfg.get("proposer", {}).get("rewrites", 3)
        self.max_snippets = cfg.get("proposer", {}).get("max_snippets", 6)
        self.min_question_len = cfg.get("proposer", {}).get("min_question_len", 20)
        self.forbid_answer_leak = cfg.get("proposer", {}).get("forbid_answer_leak", True)
    
    async def propose(
        self,
        seed_answer: str,
        context: Optional[EpisodeContext] = None
    ) -> Tuple[str, List[str], Dict[str, Any]]:
        """
        Generate a question from a seed answer WITH EVIDENCE GATHERING.
        
        Args:
            seed_answer: Ground truth answer to build a question around
            context: Additional context for the proposal
            
        Returns:
            Tuple of (question, evidence_snippets, metadata)
        """
        t0 = time.time()
        
        # 1. Generate query rewrites for evidence gathering
        rewrites = self._generate_query_rewrites(seed_answer)
        
        # 2. Gather evidence using each rewrite
        all_evidence = []
        for rewrite in rewrites:
            # Search for evidence related to this rewrite
            snippets = await self.solution_search.search(
                rewrite, 
                seed_answer=seed_answer,
                context=context
            )
            all_evidence.extend(snippets)
            
            # Deduplicate evidence
            all_evidence = list(dict.fromkeys(all_evidence))
            
            # Limit total evidence
            if len(all_evidence) >= self.max_snippets:
                break
        
        # 3. Craft question using the gathered evidence
        question, meta = await self._craft_question(
            seed_answer, 
            all_evidence,
            context
        )
        
        # 4. Apply basic validation
        if not question or len(question) < self.min_question_len:
            return "", all_evidence, {
                "rationale": "Question too short after validation",
                "difficulty": 0,
                "verifiability": 0,
                "raw_ok": False
            }
        
        # 5. Record metrics for VPM
        dt = round(time.time() - t0, 3)
        if self.vpm_control:
            self.vpm_control.decide(
                unit=f"proposer:{hash(seed_answer) & 0xffff:04x}",
                kind="text",
                dims={
                    "evidence_quality": len(all_evidence) / self.max_snippets,
                    "question_length": min(1.0, len(question) / 100),
                },
                step_idx=context.get("step_idx", 0) if context else 0,
                meta={
                    "seed_answer": seed_answer,
                    "evidence_count": len(all_evidence),
                    "question_length": len(question),
                }
            )
        
        return question, all_evidence, meta
    
    def _generate_query_rewrites(self, seed_answer: str) -> List[str]:
        """
        Generate query rewrites for evidence gathering.
        
        Args:
            seed_answer: Ground truth answer
            
        Returns:
            List of query rewrites
        """
        # Base rewrites - could be enhanced with LLM-based rewrites
        rewrites = [
            f"What is {seed_answer}?",
            f"Explain {seed_answer} in detail",
            f"How does {seed_answer} work?"
        ]
        
        # Add more rewrites based on configuration
        additional = self.cfg.get("proposer", {}).get("additional_rewrites", [])
        for pattern in additional:
            rewrites.append(pattern.format(seed_answer=seed_answer))
            
        return rewrites[:self.rewrites]  # Limit to configured number
    
    async def _craft_question(
        self,
        seed_answer: str,
        evidence: List[str],
        context: Optional[EpisodeContext] = None
    ) -> Tuple[str, Dict[str, Any]]:
        """
        Craft a question using the gathered evidence.
        
        Args:
            seed_answer: Ground truth answer
            evidence: Evidence snippets gathered
            context: Additional context
            
        Returns:
            Tuple of (question, metadata)
        """
        # Prepare context for prompt
        merged_context = {
            "seed_answer": seed_answer,
            "evidence": "\n".join(evidence),
            **(context or {})
        }
        
        prompt = self.prompt_loader.from_text(PROPOSER_PROMPT, merged_context)

        # # Load prompt
        # if self._prompt_name:
        #     prompt = self.prompt_loader.from_file(f"{self._prompt_name}.txt", self.cfg, merged_context)
        #     psrc = f"file:{self._prompt_name}.txt"
        # else:
        #     prompt = self.prompt_loader.from_text(self._prompt_text or PROPOSER_PROMPT, merged_context)
        #     psrc = "inline"
        
        _logger.debug("Proposer: loaded prompt (%s)", prompt)
        
        # Call model with retry logic
        response = ""
        attempt = 0
        while attempt <= self.retries:
            try:
                response = await self.prompt_service.run_prompt(prompt, merged_context)
                break
            except Exception as e:
                attempt += 1
                self.logger.exception("Proposer prompt call failed (attempt %d): %s", attempt, e)
                if attempt > self.retries:
                    return "", {
                        "rationale": "Failed to generate question after retries",
                        "difficulty": 0,
                        "verifiability": 0,
                        "raw_ok": False
                    }
                await asyncio.sleep(self._backoff * attempt)
        
        # Parse response
        _logger.debug("Proposer LLM response (first 160 chars): %s", 
                         (response or " ").replace("\n", " ")[:160])
        parsed = parse_proposer_lines(response)
        
        # Normalize and validate question
        question = self._normalize_question(parsed.get("question", ""))
        meta = {
            "rationale": parsed.get("rationale", ""),
            "difficulty": int(parsed.get("difficulty", 0) or 0),
            "verifiability": int(parsed.get("verifiability", 0) or 0),
            "raw_ok": bool(parsed.get("ok", False)),
        }
        
        return question, meta
    
    def _normalize_question(self, text: str) -> str:
        """Clean and normalize the generated question."""
        if not text:
            return ""
        
        # Remove trailing question marks if duplicated
        text = re.sub(r"\?+", "?", text)
        text = text.strip()
        
        # Ensure it ends with a question mark
        if text and not text.endswith("?"):
            text += "?"
            
        return text
    
    def get_capabilities(self) -> Dict[str, Any]:
        return {
            "supports_search_during_proposal": True,
            "max_evidence_snippets": self.max_snippets,
            "min_question_length": self.min_question_len
        }
``n

## File: impl\solvers\ats_solver.py

`python
"""
ATSSolver Implementation with Verification Mode

This implementation adds the critical verification mode where the solver
answers WITHOUT SEARCH using ONLY the proposer's evidence, as required
by the RAG-gated verification in the SSP paper.
"""

import heapq
import uuid
from collections import deque
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from stephanie.components.ssp.core.roles.solver import Solver 

from stephanie.components.ssp.core.protocols import EpisodeContext, VerificationResult
from stephanie.utils.progress_mixin import ProgressMixin
from stephanie.components.ssp.core.node import Node

# System prompt for verification mode (NO SEARCH)
PROMPT_VERIFICATION = """
SYSTEM:
You are verifying if a question can be answered using ONLY the provided evidence.
DO NOT PERFORM ANY SEARCH. Use ONLY the evidence snippets provided below.

EVIDENCE:
{evidence}

QUESTION:
{question}

INSTRUCTIONS:
1. Analyze if the evidence contains sufficient information to answer the question
2. If yes, provide the answer based on the evidence
3. If no, state that the evidence is insufficient
4. DO NOT INVENT INFORMATION NOT IN THE EVIDENCE

OUTPUT FORMAT:
answer: [your answer or "INSUFFICIENT EVIDENCE"]
rationale: [brief explanation]
"""


@dataclass
class ATSSolver(Solver, ProgressMixin):
    """
    Agentic Tree Search Solver with verification mode.
    
    This implements the ATS solver from the SSP paper with two modes:
    1. Verification mode: answers using ONLY proposer's evidence (no search)
    2. Deep search mode: performs full search to find the best answer
    """
    
    def __init__(
        self,
        cfg: Dict[str, Any],
        memory: Any,
        container: Any,
        logger: Any,
        searcher: Any,  # Should be SolutionSearch
        *,
        event_emitter: Optional[Any] = None,
    ):
        """
        Initialize the ATSSolver.
        
        Args:
            searcher: SolutionSearch instance for retrieval
            max_depth: Maximum search depth
            beam_width: Width of the beam search
            event_emitter: Event emitter for telemetry
            topic: Topic prefix for events
            container: Dependency container
            logger: Logger instance
        """
        self.cfg = cfg
        self.container = container
        self.memory = memory
        self.logger = logger
        self.events = event_emitter
        self.searcher = searcher
        self.max_depth = cfg.get("max_depth", 2)
        self.beam_width = cfg.get("beam_width", 3)
        self.topic = cfg.get("topic", "ssp.ats")
        
        # Get VPM control service
        self.vpm_control = container.get("vpm_control_service")
        self._init_progress(container, logger=logger)
    
    async def solve(
        self,
        question: str,
        seed_answer: str,
        context: Optional[EpisodeContext] = None,
        use_search: bool = True,
        evidence_snippets: Optional[List[str]] = None
    ) -> Tuple[str, List[str], int, Dict[str, Any]]:
        """
        Solve a question using the appropriate search strategy.
        
        Args:
            question: Question to answer
            seed_answer: Ground truth answer (for search guidance)
            context: Additional context for solving
            use_search: Whether to perform search (False for verification mode)
            evidence_snippets: Optional evidence to use (for verification mode)
            
        Returns:
            Tuple of (predicted_answer, evidence_used, steps_taken, metadata)
        """
        if not use_search and evidence_snippets:
            # Verification mode: answer using ONLY the provided evidence
            return await self._verify_with_evidence(question, seed_answer, evidence_snippets)
        
        # Deep search mode: perform full search
        return await self._deep_search(question, seed_answer, context)
    
    async def verify_answer(
        self,
        question: str,
        seed_answer: str,
        evidence_snippets: List[str]
    ) -> VerificationResult:
        """
        Verify an answer using ONLY the provided evidence (no search).
        
        This implements the RAG-gated verification step from the paper.
        
        Args:
            question: Question to answer
            seed_answer: Ground truth answer to verify against
            evidence_snippets: Evidence gathered by the Proposer
            
        Returns:
            VerificationResult object with verification outcome
        """
        # First, check if evidence is sufficient
        if not evidence_snippets:
            return VerificationResult(
                is_valid=False,
                score=0.0,
                reason="No evidence provided",
                filter_results={"evidence_usage": False},
                verification_details={"evidence_count": 0}
            )
        
        # Run verification in no-search mode
        predicted, _, _, meta = await self.solve(
            question,
            seed_answer,
            use_search=False,
            evidence_snippets=evidence_snippets
        )
        
        # Calculate score (F1 or exact match)
        score = self._calculate_verification_score(seed_answer, predicted)
        
        # Determine if verification passed
        threshold = self.container.cfg.get("verify", {}).get("pass_threshold", 0.75)
        is_valid = score >= threshold
        
        return VerificationResult(
            is_valid=is_valid,
            score=score,
            reason=f"Verification {'passed' if is_valid else 'failed'} (score={score:.2f})",
            filter_results={"evidence_usage": True},
            verification_details={
                "predicted": predicted,
                "score": score,
                "threshold": threshold
            }
        )
    
    async def _verify_with_evidence(
        self,
        question: str,
        seed_answer: str,
        evidence_snippets: List[str]
    ) -> Tuple[str, List[str], int, Dict[str, Any]]:
        """
        Answer a question using ONLY the provided evidence (no search).
        
        Args:
            question: Question to answer
            seed_answer: Ground truth answer
            evidence_snippets: Evidence to use
            
        Returns:
            Tuple of (predicted_answer, evidence_used, steps_taken, metadata)
        """
        # Prepare context for verification prompt
        merged_context = {
            "question": question,
            "evidence": "\n".join(evidence_snippets),
            "seed_answer": seed_answer
        }
        
        # Load verification prompt
        prompt = self.container.get("prompt_loader").from_text(
            PROMPT_VERIFICATION,
            merged_context
        )
        
        # Call model
        response = await self.container.get("prompt_service").run_prompt(
            prompt, 
            merged_context
        )
        
        # Parse response
        lines = response.strip().splitlines()
        answer_line = next((ln for ln in lines if ln.startswith("answer:")), "")
        rationale_line = next((ln for ln in lines if ln.startswith("rationale:")), "")
        
        predicted = answer_line.replace("answer:", "").strip()
        rationale = rationale_line.replace("rationale:", "").strip()
        
        return (
            predicted,
            evidence_snippets,
            0,  # No search steps in verification mode
            {
                "rationale": rationale,
                "evidence_used": len(evidence_snippets),
                "verification_mode": True
            }
        )
    
    async def _deep_search(
        self,
        question: str,
        seed_answer: str,
        context: Optional[EpisodeContext] = None
    ) -> Tuple[str, List[str], int, Dict[str, Any]]:
        """
        Perform full search to find the best answer.
        
        Args:
            question: Question to answer
            seed_answer: Ground truth answer
            context: Additional context
            
        Returns:
            Tuple of (predicted_answer, evidence_used, steps_taken, metadata)
        """
        # - progress: start -
        task_key = f"ATS:{hash(question) & 0xffff:04x}"
        rewrites_per_parent = len(self._rewrite(question))
        total_steps = self._estimate_total_steps(rewrites_per_parent)
        self.pstart(task=task_key, total=total_steps)
        self.pstage(task=task_key, stage="root")
        
        # Initialize search
        root = Node(
            id=f"root-{uuid.uuid4().hex[:6]}",
            parent_id=None,
            root_id="root",
            depth=0,
            sibling_index=0,
            node_type="root",
            query=question,
            score=0.0,
            context="",
            task_description=question,
        )
        
        if self.events:
            self.events.on_root_created(root)
        
        best = root
        steps = 0
        done = 0
        
        # Main search loop
        for depth in range(1, self.max_depth + 1):
            self.pstage(task=task_key, stage=f"depth-{depth}")
            
            # Get current candidates (beam)
            candidates = self._get_candidates(root, depth)
            
            # Expand each candidate
            for parent in candidates:
                rewrites = self._rewrite(parent.query)
                
                for i, q2 in enumerate(rewrites):
                    # Search for evidence
                    ctx = await self.searcher.search(q2, seed_answer=seed_answer, context=context)
                    sc = self._overlap_score(ctx, seed_answer)
                    
                    # Create child node
                    child = Node(
                        id=f"node-{uuid.uuid4().hex[:6]}",
                        parent_id=parent.id,
                        root_id=root.id,
                        depth=depth,
                        sibling_index=i,
                        node_type="rewrite",
                        query=q2,
                        score=sc,
                        context=ctx,
                        task_description=question,
                    )
                    
                    if self.events:
                        self.events.on_node_added(parent, child)
                        self.events.on_backprop(child, delta=float(sc))
                    
                    # Update best node
                    if sc > best.score:
                        best = child
                        if self.events:
                            self.events.on_best_update(best)
                    
                    # Progress tracking
                    steps += 1
                    done += 1
                    self.ptick(task=task_key, done=done, total=total_steps)
            
            # Prune to beam width
            self._prune_to_beam(root)
        
        # - progress: done -
        self.pdone(task=task_key)
        
        # MVP answer extraction
        predicted_answer = best.context if best.context else seed_answer
        evidence = best.context.splitlines()
        
        if self.events:
            self.events.on_progress({
                "phase": "ats_solve_complete",
                "steps": steps,
                "best_score": best.score
            })
            self.events.on_rollout_complete({
                "best": {
                    "id": best.id,
                    "score": best.score,
                    "query": best.query,
                    "depth": best.depth,
                },
                "steps": steps,
            })
        
        return (
            predicted_answer,
            evidence,
            steps,
            {
                "best_score": best.score,
                "search_depth": best.depth,
                "evidence_count": len(evidence)
            }
        )
    
    # --- Helper methods ---
    
    @staticmethod
    def _rewrite(query: str) -> List[str]:
        """Minimal, deterministic rewrites for query expansion."""
        return [
            query,
            query.replace("explain", "describe"),
            query + " in practical terms",
        ]
    
    @staticmethod
    def _overlap_score(text: str, target: str) -> float:
        """Calculate overlap score between text and target."""
        a = set([t for t in text.lower().split() if t.isalpha() or t.isalnum()])
        b = set([t for t in target.lower().split() if t.isalpha() or t.isalnum()])
        if not a or not b:
            return 0.0
        inter = len(a & b)
        return inter / max(len(b), 1)
    
    def _estimate_total_steps(self, rewrites_per_parent: int) -> int:
        """Estimate total steps for progress tracking."""
        steps = 0
        nodes_at_depth = 1
        for _ in range(1, self.max_depth + 1):
            steps += nodes_at_depth * rewrites_per_parent
            nodes_at_depth = min(self.beam_width, nodes_at_depth * rewrites_per_parent)
        return steps
    
    def _get_candidates(self, root: Node, depth: int) -> List[Node]:
        """Get candidates at the current depth for expansion."""
        # Get all nodes at the target depth
        candidates = []
        queue = deque([root])
        
        while queue:
            node = queue.popleft()
            if node.depth == depth - 1:
                candidates.append(node)
            elif node.depth < depth - 1:
                # In a real implementation, you'd have children to explore
                pass
        
        # Sort by score and take top beam_width
        return heapq.nlargest(self.beam_width, candidates, key=lambda n: n.score)
    
    def _prune_to_beam(self, root: Node) -> None:
        """Prune the tree to keep only the top beam_width nodes at each depth."""
        # In a real implementation, this would prune the tree
        pass
    
    def _calculate_verification_score(self, ground_truth: str, predicted: str) -> float:
        """Calculate F1 score for verification."""
        # Simple implementation - in practice, use proper F1
        gt_words = set(ground_truth.lower().split())
        pred_words = set(predicted.lower().split())
        
        if not gt_words or not pred_words:
            return 0.0
            
        common = gt_words & pred_words
        precision = len(common) / len(pred_words)
        recall = len(common) / len(gt_words)
        
        if precision + recall == 0:
            return 0.0
            
        return 2 * (precision * recall) / (precision + recall)
    
    def get_capabilities(self) -> Dict[str, Any]:
        return {
            "supports_verification_mode": True,
            "max_search_depth": self.max_depth,
            "beam_width": self.beam_width
        }
``n

## File: impl\solvers\solution_search.py

`python
# stephanie/components/ssp/solution_search.py
from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from typing import Any, Dict, List, Optional

from stephanie.components.tree.events import TreeEventEmitter
from stephanie.prompts.prompt_loader import PromptLoader

_logger = logging.getLogger(__name__)

# ------------------------ Retrieval prompt (line-by-line) ------------------------
PROMPT_SOLUTION_SEARCH_LINES = """
SYSTEM:
You retrieve SHORT evidence snippets that help answer a query about a canonical mechanism (SEED_ANSWER).

SEED_ANSWER:
{{ seed_answer }}

QUERY:
{{ query }}

CONSTRAINTS:
- Provide concise, factual snippets (1–2 sentences each).
- Prefer content that directly supports or explains SEED_ANSWER in relation to QUERY.
- No commentary or extra sections.

OUTPUT FORMAT — WRITE EXACTLY {{ top_k }} LINES:
snippet: <short evidence snippet>
"""

class SolutionSearch:
    """
    LLM-backed retrieval shim for the SSP MVP.

    Usage:
      searcher = SolutionSearch(cfg, memory, container, logger, event_emitter=emitter)
      docs = await searcher.search("why do glaciers accelerate ...", seed_answer, context)

    Notes:
      - Async-first.
      - Emits: solution_search_query, solution_search_results, error (via TreeEventEmitter).
    """

    def __init__(
        self,
        cfg: Dict[str, Any],
        memory: Any,
        container: Any,
        logger: Any,
        *,
        event_emitter: Optional[TreeEventEmitter] = None,
        prompt_text: Optional[str] = PROMPT_SOLUTION_SEARCH_LINES,
        prompt_name: Optional[str] = None,   # if set, load from file "<name>.txt"
        retries: int = 1,
        backoff_sec: float = 0.5,
    ):
        self.cfg = cfg or {}
        self.memory = memory
        self.container = container
        self.logger = logger or _logger
        self.events = event_emitter  # optional sink
        self.prompt_loader = PromptLoader(memory=self.memory, logger=self.logger)
        self.prompt_service = container.get("prompt")

        # knobs
        self.k = int(self.cfg.get("k", 3))
        self.max_chars = int(self.cfg.get("max_chars_per_snippet", 400))
        self.retries = max(0, int(retries))
        self.backoff = float(backoff_sec)

        # prompt sources
        self._prompt_text = prompt_text
        self._prompt_name = prompt_name

    # ----------------------- public API -----------------------

    async def search(self, query: str, seed_answer: str, context: Dict[str, Any]) -> List[str]:
        """Return up to k evidence snippets supporting seed_answer for query."""
        t0 = time.time()
        self._emit("search_query", {"query": query, "k": self.k})

        merged_context = {
            **(context or {}),
            "query": query,
            "seed_answer": seed_answer,
            "top_k": int(self.k),
            "now_ts": int(time.time()),
        }

        # Prompt: prefer file if prompt_name provided
        if self._prompt_name:
            prompt = self.prompt_loader.from_file(f"{self._prompt_name}.txt", self.cfg, merged_context)
            psrc = f"file:{self._prompt_name}.txt"
        else:
            prompt = self.prompt_loader.from_text(self._prompt_text or PROMPT_SOLUTION_SEARCH_LINES, merged_context)
            psrc = "inline"
        _logger.debug("SolutionSearch: loaded prompt (%s), k=%d", psrc, self.k)

        # Call model with light retry
        response: str = ""
        attempt = 0
        while True:
            try:
                response = await self.prompt_service.run_prompt(prompt, merged_context)
                break
            except Exception as e:
                attempt += 1
                self.logger.exception("SolutionSearch prompt call failed (attempt %d): %s", attempt, e)
                self._emit("error", {"where": "solution_search.run_prompt", "error": str(e), "attempt": attempt})
                if attempt > self.retries:
                    snippets = self._fallback_snippets(query, seed_answer, self.k)
                    dt = round(time.time() - t0, 3)
                    self._emit("search_results", {"query": query, "k": self.k, "latency_sec": dt, "num": len(snippets)})
                    return snippets
                await asyncio.sleep(self.backoff * attempt)

        _logger.debug("SolutionSearch LLM response (first 160 chars): %s", (response or "").replace("\n", " ")[:160])

        # Parse + postprocess
        snippets = self._parse_snippets(response, self.k)
        snippets = self._postprocess(snippets, self.k) or self._fallback_snippets(query, seed_answer, self.k)

        dt = round(time.time() - t0, 3)
        self._emit("search_results", {"query": query, "k": self.k, "latency_sec": dt, "num": len(snippets)})
        return snippets

    # ----------------------- internals -----------------------

    def _parse_snippets(self, response: str, k: int) -> List[str]:
        """
        Supported formats (in order of preference):
          1) Line-by-line:  lines starting with `snippet: ...`
          2) JSON:          keys 'snippets' | 'docs' | 'evidence' | 'results'
          3) Bullets/lines: split by newline, trim bullets
        """
        if not response:
            return []

        # 1) Explicit 'snippet:' lines (case/space tolerant)
        lines = [ln.strip() for ln in response.splitlines() if ln.strip()]
        snips: List[str] = []
        for ln in lines:
            m = re.match(r'(?i)^\s*(?:-|\d+[.)])?\s*snippet\s*[:=]\s*(.+?)\s*$', ln)
            if m:
                snips.append(m.group(1).strip())
        if snips:
            return snips[:k]

        # 2) JSON (fenced or bare)
        m = re.search(r"```json\s*(\{.*?\})\s*```", response, re.DOTALL | re.IGNORECASE)
        jtxt = m.group(1) if m else response.strip()
        if jtxt.startswith("{") and jtxt.endswith("}"):
            try:
                obj = json.loads(jtxt)
                lst = self._pluck_list(obj)
                if lst:
                    return lst[:k]
            except Exception:
                pass

        # 3) Fallback: plain lines/bullets
        bullets = [b.strip(" -*•\t") for b in lines]
        bullets = [b for b in bullets if b]
        return bullets[:k]

    def _pluck_list(self, obj: Dict[str, Any]) -> Optional[List[str]]:
        for key in ("snippets", "docs", "evidence", "results"):
            v = obj.get(key)
            if isinstance(v, list):
                # filter non-strings conservatively
                return [str(x) for x in v if isinstance(x, (str, int, float))]
        return None

    def _postprocess(self, snippets: List[str], k: int) -> List[str]:
        """Dedup, clip length, and ensure non-empty."""
        seen = set()
        out: List[str] = []
        for s in snippets:
            s = str(s).strip()
            if not s:
                continue
            if len(s) > self.max_chars:
                s = s[: self.max_chars].rstrip()
            if s not in seen:
                seen.add(s)
                out.append(s)
            if len(out) >= k:
                break
        return out

    def _fallback_snippets(self, query: str, seed_answer: str, k: int) -> List[str]:
        base = (
            f"DOC: On '{query}', note that a key mechanism is: {seed_answer}. "
            f"This may interact with other factors, but {seed_answer} remains central."
        )
        return [base + f" [hit:{i}]" for i in range(k)]

    def _emit(self, event: str, payload: Dict[str, Any]) -> None:
        if not self.events:
            return
        try:
            if event == "search_query":
                self.events.on_progress({"phase": "solution_search_query", **payload})
            elif event == "search_results":
                self.events.on_progress({"phase": "solution_search_results", **payload})
            elif event == "error":
                self.events.on_error(payload.get("error", ""), "solution_search", payload)
            else:
                self.events.on_progress({"phase": event, **payload})
        except Exception:
            pass
``n

## File: impl\verifiers\f1_verifier.py

`python
# stephanie/components/ssp/impl/verifiers/f1_verifier.py

from __future__ import annotations

from typing import Tuple

class Verifier:
    def __init__(self, cfg, memory, container, logger):
        self.cfg = cfg
        self.memory = memory
        self.container = container
        self.logger = logger
        self.threshold = cfg.get("threshold", 0.6)

    @staticmethod
    def _f1_ref(text_a: str, text_b: str) -> float:
        a = text_a.lower().split()
        b = text_b.lower().split()
        if not a or not b:
            return 0.0
        inter = len(set(a) & set(b))
        p = inter / max(len(a), 1)
        r = inter / max(len(b), 1)
        if p + r == 0:
            return 0.0
        return 2 * p * r / (p + r)

    def verify(self, ground_truth: str, predicted: str) -> Tuple[bool, float]:
        score = self._f1_ref(ground_truth, predicted)
        return (score >= self.threshold), score
``n

## File: impl\verifiers\rag_verifier.py

`python
"""
RAG-Gated Verifier Implementation

This implementation performs the critical RAG-gated verification step
from the SSP paper:
1. Applies rule-based filters to the question
2. Runs verification using the solver in NO-SEARCH mode with proposer's evidence
3. Determines if the question should be accepted for deep search
"""

import asyncio
import re
from typing import Any, Dict, List, Optional, Tuple

from stephanie.components.ssp.core.roles import Verifier
from stephanie.components.ssp.core.protocols import EpisodeContext, VerificationResult
from stephanie.components.ssp.utils.filters import (
    check_question_length,
    check_answer_leakage,
    check_evidence_usage,
    check_tool_usage,
    check_format
)


class RAGVerifier(Verifier):
    """
    Verifier implementation that performs RAG-gated verification.
    
    This implements the paper's verification process:
    1. Apply rule-based filters
    2. Run verification using Solver with ONLY proposer's evidence
    3. Determine if question should be accepted
    """
    
    def __init__(
        self,
        cfg: Dict[str, Any],
        memory: Any,
        container: Any,
        logger: Any = None,
        solver: Any = None
    ):
        """
        Initialize the RAGVerifier.
        
        Args:
            cfg: Configuration dictionary
            memory: Memory tool
            container: Dependency container
            logger: Logger instance
            solver: Optional pre-configured Solver instance
        """
        self.cfg = cfg
        self.memory = memory
        self.container = container
        self.logger = logger
        self.solver = solver or container.get("solver")
        
        if not self.solver:
            raise ValueError("Solver is required for verification")
        
        # Configuration parameters
        self.min_question_len = cfg.get("verify", {}).get("min_question_len", 20)
        self.forbid_answer_leak = cfg.get("verify", {}).get("forbid_answer_leak", True)
        self.min_evidence_count = cfg.get("verify", {}).get("min_evidence_count", 1)
        self.pass_threshold = cfg.get("verify", {}).get("pass_threshold", 0.75)
    
    def apply_filters(
        self,
        question: str,
        evidence_snippets: List[str],
        seed_answer: str
    ) -> Tuple[bool, List[str]]:
        """
        Apply rule-based filters to a question.
        
        Args:
            question: Question to filter
            evidence_snippets: Evidence gathered by the Proposer
            seed_answer: Ground truth answer
            
        Returns:
            Tuple of (is_valid, list_of_failed_rules)
        """
        failed_rules = []
        
        # Check question length
        if not check_question_length(question, self.min_question_len):
            failed_rules.append(f"question_too_short (< {self.min_question_len} chars)")
        
        # Check for answer leakage
        if self.forbid_answer_leak and check_answer_leakage(question, seed_answer):
            failed_rules.append("answer_leakage_detected")
        
        # Check evidence usage
        if not check_evidence_usage(evidence_snippets, self.min_evidence_count):
            failed_rules.append(f"insufficient_evidence (< {self.min_evidence_count})")
        
        # Check tool usage (evidence must come from search)
        if not check_tool_usage(evidence_snippets):
            failed_rules.append("no_tool_usage_detected")
        
        # Check format
        if not check_format(question):
            failed_rules.append("invalid_format")
        
        return len(failed_rules) == 0, failed_rules
    
    async def verify(
        self,
        question: str,
        seed_answer: str,
        evidence_snippets: List[str],
        context: Optional[EpisodeContext] = None
    ) -> VerificationResult:
        """
        Verify a question meets all criteria for deep search.
        
        This implements the paper's RAG-gated verification:
        1. Apply rule-based filters
        2. Run verification using Solver with ONLY proposer's evidence
        3. Determine if question should be accepted
        
        Args:
            question: Question to verify
            seed_answer: Ground truth answer
            evidence_snippets: Evidence gathered by the Proposer
            context: Additional context for verification
            
        Returns:
            VerificationResult object with verification outcome
        """
        # 1. Apply rule-based filters
        filters_valid, failed_rules = self.apply_filters(
            question, 
            evidence_snippets,
            seed_answer
        )
        
        if not filters_valid:
            return VerificationResult(
                is_valid=False,
                score=0.0,
                reason=f"Failed rule-based filters: {', '.join(failed_rules)}",
                filter_results={rule.split('(')[0]: False for rule in failed_rules},
                verification_details={"failed_rules": failed_rules}
            )
        
        # 2. Run RAG-gated verification (solver with no search)
        verification_result = await self.solver.verify_answer(
            question,
            seed_answer,
            evidence_snippets
        )
        
        # 3. Determine if question should be accepted
        is_valid = verification_result.is_valid
        
        return VerificationResult(
            is_valid=is_valid,
            score=verification_result.score,
            reason=verification_result.reason,
            filter_results={rule.split('(')[0]: True for rule in failed_rules} if filters_valid else 
                         {rule.split('(')[0]: False for rule in failed_rules},
            verification_details=verification_result.verification_details
        )
    
    def get_filter_rules(self) -> List[Dict[str, Any]]:
        """Return the current filter rules configuration."""
        return [
            {
                "name": "question_length",
                "description": f"Question must be at least {self.min_question_len} characters",
                "enabled": True,
                "min_length": self.min_question_len
            },
            {
                "name": "answer_leakage",
                "description": "Question must not contain the seed answer",
                "enabled": self.forbid_answer_leak
            },
            {
                "name": "evidence_usage",
                "description": f"Must have at least {self.min_evidence_count} evidence snippets",
                "enabled": True,
                "min_count": self.min_evidence_count
            },
            {
                "name": "tool_usage",
                "description": "Evidence must come from search tool usage",
                "enabled": True
            },
            {
                "name": "format",
                "description": "Question must be properly formatted",
                "enabled": True
            }
        ]
    
    def get_verification_threshold(self) -> float:
        """Return the current verification score threshold."""
        return self.pass_threshold
``n

## File: retrievers\base.py

`python
# stephanie/components/ssp/retrievers/base.py
from __future__ import annotations
from typing import Any, Dict, List

class BaseRetriever:
    async def retrieve(self, query: str, seed_answer: str, context: Dict[str, Any], k: int) -> List[str]:
        raise NotImplementedError
``n

## File: retrievers\prompt_history.py

`python
# stephanie/components/ssp/retrievers/prompt_history.py
from __future__ import annotations
import asyncio
from typing import Any, Dict, List, Optional

from .base import BaseRetriever

def _maybe_sync(x):
    # await coroutine or return sync result
    if asyncio.iscoroutine(x):
        return x
    async def _wrap(): return x
    return _wrap()

class PromptHistoryRetriever(BaseRetriever):
    """
    Pull short evidence snippets from local history stores (CaseBooks/Chats/Traces).
    Tries a few common repos; degrades gracefully if unavailable.
    """
    def __init__(self, memory: Any, max_chars: int = 400):
        self.memory = memory
        self.max_chars = int(max_chars)

    async def retrieve(self, query: str, seed_answer: str, context: Dict[str, Any], k: int) -> List[str]:
        repos = [
            ("casebooks", "search"),   # preferred
            ("chat_repo", "search"),
            ("traces", "search"),
            ("docs", "search"),
        ]
        out: List[str] = []
        for name, meth in repos:
            repo = getattr(self.memory, name, None)
            if not repo: 
                continue
            fn = getattr(repo, meth, None)
            if not fn:
                continue
            try:
                # try async first (await) then sync
                hits = await _maybe_sync(fn(query, top_k=k))
                for h in hits or []:
                    # tolerate different shapes
                    txt = (h.get("assistant_text")
                           or h.get("text")
                           or h.get("content")
                           or str(h))[: self.max_chars]
                    txt = (txt or "").strip()
                    if txt:
                        out.append(txt)
                        if len(out) >= k:
                            return out
            except Exception:
                continue
        return out[:k]
``n

## File: services\state_service.py

`python
# stephanie/components/ssp/services/state_service.py
from __future__ import annotations

import time
from collections import defaultdict, deque
from typing import Any, Dict, Optional, List

from stephanie.services.service_protocol import Service


class StateService(Service):
    """
    Centralized state management service for the Self-Play System (SSP).

    Tracks:
    - Active episodes (proposal → solve → verify lifecycle)
    - Curriculum difficulty & success history
    - Per-dimension performance metrics
    - Component status and metadata
    - Ring buffers for recent activity

    Provides:
    - Real-time observability into SSP progress
    - Safe access to shared state for actors (Proposer, Solver, Verifier)
    - Historical data for adaptive control (e.g., Q-Max logic)
    - Integration points for UIs, dashboards, and logging.
    """

    def __init__(self, cfg: Dict[str, Any], memory, logger, container=None):
        self.cfg = cfg or {}
        self.memory = memory
        self.logger = logger
        self.container = container
        self._initialized = False

        # --- Core State ---
        # General configuration and component status
        self.state: Dict[str, Any] = {
            "episode_count": 0,
            "current_difficulty": 0.3,
            "success_rate": 0.0,
            "last_episode_id": None,
            "status": "idle",  # 'idle', 'running', 'paused'
            "start_time": None,
            "last_update": time.time(),
        }

        # Ring buffer of recent episode outcomes (1=success, 0=failure) for curriculum
        window_size = int(self.cfg.get("state", {}).get("competence_window", 100))
        self.success_history: deque[int] = deque(maxlen=window_size)

        # Track active proposals/solutions per goal or session
        self.active_episodes: Dict[str, Dict[str, Any]] = {}

        # Per-dimension scoring trends (simple moving average)
        self.dimension_scores: Dict[str, deque[float]] = defaultdict(
            lambda: deque(maxlen=50)
        )

        # Recent queries proposed (for novelty checks)
        self.recent_queries: deque[str] = deque(maxlen=200)

        # --- Configuration ---
        c = self.cfg.get("state", {})
        self._buffer_recent_traces = bool(c.get("enable_trace_buffer", True))
        self._max_trace_buffer = int(c.get("trace_buffer_size", 1000))
        self._log_state_updates = bool(c.get("log_state_changes", True))

        # Trace/event ring buffer if enabled
        self._recent_events: Optional[deque[Dict[str, Any]]] = (
            deque(maxlen=self._max_trace_buffer)
            if self._buffer_recent_traces
            else None
        )

    # === Service Protocol ===

    def initialize(self, **kwargs) -> None:
        """Initialize the state service."""
        if self._initialized:
            return

        self._initialized = True
        self.state["start_time"] = time.time()
        self.state["status"] = "idle"

        if self.logger:
            self.logger.log(
                "StateServiceInit",
                {"status": "initialized", "config": self.cfg.get("state", {})}
            )

        # Optionally persist initial state
        if self.memory:
            try:
                self.memory.save("state_service", {"service_state": dict(self.state)})
            except Exception as e:
                if self.logger:
                    self.logger.log(
                        "StateServiceWarning",
                        {"event": "init_persist_failed", "error": str(e)}
                    )

    def health_check(self) -> Dict[str, Any]:
        """Return service health and summary of tracked state."""
        status = "healthy" if self._initialized else "unhealthy"
        now = time.time()

        return {
            "status": status,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now)),
            "metrics": {
                "episode_count": self.state["episode_count"],
                "current_difficulty": self.state["current_difficulty"],
                "recent_success_rate": self.state["success_rate"],
                "active_episodes": len(self.active_episodes),
                "tracked_dimensions": len(self.dimension_scores),
                "recent_query_count": len(self.recent_queries),
            },
            "dependencies": {
                "memory": self.memory is not None,
                "logger": self.logger is not None,
                "container": self.container is not None,
            },
            "last_update": self.state["last_update"],
        }

    def shutdown(self) -> None:
        """Clear all state and mark as uninitialized."""
        self.state.clear()
        self.success_history.clear()
        self.active_episodes.clear()
        self.dimension_scores.clear()
        self.recent_queries.clear()
        if self._recent_events:
            self._recent_events.clear()

        self._initialized = False

        if self.logger:
            self.logger.log("StateServiceShutdown", {"event": "shutdown_complete"})

    @property
    def name(self) -> str:
        return "ssp-state-service"

    # === Domain Logic - Episode Management ===

    def start_episode(self, episode_id: str, proposal: Dict[str, Any]) -> None:
        """Record the start of a new SSP episode."""
        now = time.time()
        self.active_episodes[episode_id] = {
            "episode_id": episode_id,
            "proposal": proposal,
            "started_at": now,
            "status": "proposed",
            "difficulty": proposal.get("difficulty", 0.3),
        }
        self.state["last_episode_id"] = episode_id
        self.state["episode_count"] += 1
        self.state["last_update"] = now

        self._log_event("episode_started", {"episode_id": episode_id})
        self._persist_state_snapshot()

    def update_episode_solution(self, episode_id: str, solution: Dict[str, Any]) -> None:
        """Update an episode with its solution."""
        if episode_id not in self.active_episodes:
            return

        self.active_episodes[episode_id].update({
            "solution": solution,
            "solved_at": time.time(),
            "status": "solved"
        })
        self.state["last_update"] = time.time()

        # Extract and record query for novelty checks
        query = solution.get("reasoning_path", [{}])[0].get("description", "")
        if query.strip():
            self.add_recent_query(query.strip())

        self._log_event("episode_solved", {"episode_id": episode_id})
        self._persist_state_snapshot()

    def complete_episode(
        self, episode_id: str, verification: Dict[str, Any], metrics: Dict[str, float]
    ) -> None:
        """Finalize an episode with verification results."""
        if episode_id not in self.active_episodes:
            return

        ep = self.active_episodes[episode_id]
        now = time.time()
        success = bool(verification.get("is_valid", False))

        ep.update({
            "verification": verification,
            "metrics": metrics,
            "completed_at": now,
            "success": success,
            "status": "verified" if success else "failed"
        })

        # Update global success history and rate
        self.success_history.append(1 if success else 0)
        self.state["success_rate"] = (
            sum(self.success_history) / len(self.success_history)
            if self.success_history else 0.0
        )

        # Update dimension scores
        dim_scores = verification.get("dimension_scores", {})
        for dim, score in dim_scores.items():
            self.dimension_scores[dim].append(float(score))

        self.state["current_difficulty"] = metrics.get("difficulty", self.state["current_difficulty"])
        self.state["last_update"] = now

        self._log_event("episode_completed", {
            "episode_id": episode_id,
            "success": success,
            "difficulty": self.state["current_difficulty"],
            "success_rate": self.state["success_rate"]
        })
        self._persist_state_snapshot()

    def get_episode(self, episode_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve the full state of a specific episode."""
        return self.active_episodes.get(episode_id)

    def get_recent_episodes(self, limit: int = 10, success: Optional[bool] = None) -> List[Dict[str, Any]]:
        """Get a list of recently completed episodes, optionally filtered by success."""
        completed = [
            ep for ep in self.active_episodes.values()
            if ep.get("status") in ("verified", "failed")
        ]
        # Sort by completion time (assuming 'completed_at' exists)
        completed.sort(key=lambda x: x.get("completed_at", 0), reverse=True)
        
        if success is not None:
            completed = [ep for ep in completed if ep.get("success") == success]

        return completed[:limit]

    # === Domain Logic - Curriculum & Metrics ===

    def get_curriculum_state(self) -> Dict[str, Any]:
        """Get current curriculum parameters."""
        return {
            "current_difficulty": self.state["current_difficulty"],
            "success_rate": self.state["success_rate"],
            "success_history": list(self.success_history),
            "competence_window": self.success_history.maxlen,
            "target_success_rate": 0.7,  # Could be config-driven
        }

    def update_curriculum(self, new_difficulty: float, success: bool) -> None:
        """Update the curriculum state from trainer feedback."""
        self.state["current_difficulty"] = float(new_difficulty)
        self.state["last_update"] = time.time()
        # The Trainer already updates success_history; we just reflect it
        self.state["success_rate"] = (
            sum(self.success_history) / len(self.success_history)
            if self.success_history else 0.0
        )
        self._log_event("curriculum_updated", {
            "new_difficulty": new_difficulty,
            "success_rate": self.state["success_rate"]
        })

    def get_dimension_trend(self, dimension: str) -> Dict[str, Any]:
        """Get the recent score history for a specific dimension."""
        scores = list(self.dimension_scores[dimension])
        return {
            "dimension": dimension,
            "recent_scores": scores,
            "average_score": sum(scores) / len(scores) if scores else 0.5,
            "count": len(scores),
            "trend": "increasing" if len(scores) > 1 and scores[-1] > scores[0] else "stable"
        }

    # === Domain Logic - Query & Context Management ===

    def add_recent_query(self, query: str) -> None:
        """Add a query to the recent history for novelty checks."""
        if query.strip():
            self.recent_queries.append(query.strip())
            self._log_event("query_added", {"query_length": len(query)})

    def get_ring_buffer(self, key: str, maxlen: int = 100) -> deque:
        """
        Provide access to internal ring buffers.
        Used by actors (e.g., Proposer) for lightweight state sharing.
        """
        if key == "ssp.recent_queries":
            # Ensure the buffer has the requested maxlen
            if len(self.recent_queries) > maxlen:
                # Trim from the left if necessary
                while len(self.recent_queries) > maxlen:
                    self.recent_queries.popleft()
            return self.recent_queries
        # Add other buffers here as needed
        return deque(maxlen=maxlen)

    # === Internal Helpers ===

    def _log_event(self, event_type: str, payload: Dict[str, Any]) -> None:
        """Log a state change event if configured."""
        if not self._log_state_updates or not self.logger:
            return

        full_payload = {
            "event": event_type,
            "timestamp": time.time(),
            "service": self.name,
            **payload
        }
        self.logger.log(f"StateServiceEvent", extra=full_payload)

        # Add to in-memory event ring buffer
        if self._recent_events is not None:
            self._recent_events.append(full_payload)

    def _persist_state_snapshot(self) -> None:
        """Persist the current state snapshot to memory if available."""
        if not self.memory or not hasattr(self.memory, "save"):
            return

        try:
            snapshot = {
                "state": dict(self.state),
                "success_history": list(self.success_history),
                "active_episodes_count": len(self.active_episodes),
                "last_update": self.state["last_update"]
            }
            # Use a stable key
            self.memory.save("ssp_global_state", snapshot)
        except Exception as e:
            if self.logger:
                self.logger.log(
                    "StateServiceWarning",
                    {"event": "persist_snapshot_failed", "error": str(e)}
                )

    # === Debugging ===

    def __repr__(self):
        active_count = len(self.active_episodes)
        recent_success = f"{self.state['success_rate']:.2%}"
        return (
            f"<StateService: status={self.state['status']} "
            f"episodes={self.state['episode_count']} "
            f"active={active_count} "
            f"difficulty={self.state['current_difficulty']:.2f} "
            f"success_rate={recent_success}>"
        )
``n

## File: services\vpm_control_service.py

`python
# stephanie/components/ssp/services/vpm_control_service.py
"""
VPM Control Service - Manages Vectorized Performance Map decision-making for SSP components

This service provides the core control loop for the Self-Play System (SSP), using VPM (Vectorized 
Performance Map) methodology to make decisions about when to continue refining, resample, escalate,
or stop processing based on multi-dimensional performance metrics.

Key features:
- Integrates with the VPMController for trend-aware decision making
- Manages state for multiple processing units (questions, episodes, etc.)
- Generates VPM visualization artifacts for monitoring and analysis
- Supports bandit-based exemplar selection for adaptive refinement
- Provides goal-aware stopping conditions based on configured targets

The service follows the Service Protocol interface for integration with the Stephanie framework.
"""

from __future__ import annotations

import os
import time
import json
from dataclasses import asdict
from typing import Any, Callable, Dict, List, Optional

from stephanie.logging.json_logger import JSONLogger
from stephanie.memory.memory_tool import MemoryTool
from stephanie.services.service_protocol import Service

# Import VPM core components from the examples provided
from stephanie.zeromodel.vpm_controller import (
    Thresholds, 
    Policy, 
    VPMRow, 
    Decision,
    VPMController as CoreVPMController
)
from stephanie.zeromodel.vpm_phos import (
    build_vpm_phos_artifacts
)

class VPMControlService(Service):
    """
    Service for managing VPM-based control decisions within the SSP framework.
    
    This service:
    - Creates and manages VPMControllers for individual processing units
    - Makes decisions based on multi-dimensional performance metrics
    - Generates VPM visualization artifacts for monitoring
    - Integrates with bandit systems for adaptive exemplar selection
    - Provides goal-aware stopping conditions
    
    The service follows a stateful pattern where each processing unit (e.g., question, episode)
    has its own controller instance that tracks its performance history.
    """
    
    def __init__(
        self, 
        cfg: Dict[str, Any], 
        memory: MemoryTool, 
        logger: JSONLogger, 
        container: Optional[Any] = None
    ):
        """
        Initialize the VPM Control Service.
        
        Args:
            cfg: Configuration dictionary with VPM parameters
            memory: Memory tool for state persistence
            logger: JSON logger for structured logging
            container: Dependency injection container
        """
        self.cfg = cfg or {}
        self.memory = memory
        self.logger = logger
        self.container = container
        self._initialized = False

        # Service state
        self._controllers: Dict[str, CoreVPMController] = {}
        self._bus = getattr(memory, "bus", None)
        
        # Configuration setup
        self._setup_configuration()
        
        # Visualization configuration
        self._setup_visualization_paths()
        
        # Bandit integration
        self._bandit_choose: Optional[Callable[[List[str]], str]] = None
        self._bandit_update: Optional[Callable[[str, float], None]] = None
        
        # Metrics tracking
        self._metrics_history: Dict[str, List[Dict[str, float]]] = {}

    def _setup_configuration(self) -> None:
        """Configure thresholds, policies, and parameters from config."""
        c = (self.cfg.get("vpm_control") or {})
        
        # Code thresholds (for code-related processing)
        self._thr_code = Thresholds(
            mins=c.get("mins_code", {
                "tests_pass_rate": 1.0,
                "coverage": 0.70,
                "type_safe": 1.0,
                "lint_clean": 1.0,
                "complexity_ok": 0.8,
            }),
            stop_margin=float(c.get("stop_margin_code", 0.0)),
            edit_margin=float(c.get("edit_margin_code", 0.0)),
        )
        
        # Text thresholds (for question/answer processing)
        self._thr_text = Thresholds(
            mins=c.get("mins_text", {
                "coverage": 0.80,
                "correctness": 0.75,
                "coherence": 0.75,
                "citation_support": 0.65,
                "entity_consistency": 0.80,
            }),
            stop_margin=float(c.get("stop_margin_text", 0.02)),
            edit_margin=float(c.get("edit_margin_text", 0.01)),
        )
        
        # Policy configuration
        self._policy = Policy(
            window=int(c.get("window", 5)),
            ema_alpha=float(c.get("ema_alpha", 0.4)),
            edit_margin=float(c.get("edit_margin", 0.05)),
            patience=int(c.get("patience", 3)),
            escalate_after=int(c.get("escalate_after", 2)),
            oscillation_window=int(c.get("oscillation_window", 6)),
            oscillation_threshold=int(c.get("oscillation_threshold", 3)),
            cooldown_steps=int(c.get("cooldown_steps", 1)),
            spinoff_dim=str(c.get("spinoff_dim", "novelty")),
            stickiness_dim=str(c.get("stickiness_dim", "stickiness")),
            spinoff_gate=tuple(c.get("spinoff_gate", (0.75, 0.45))),
            max_regressions=int(c.get("max_regressions", 2)),
            zscore_clip_dims=list(c.get("zscore_clip_dims", [
                "coverage", "coherence", "correctness", "tests_pass_rate"
            ])),
            zscore_clip_sigma=float(c.get("zscore_clip_sigma", 3.5)),
            local_gap_dims=list(c.get("local_gap_dims", [
                "citation_support", "entity_consistency", "lint_clean", "type_safe"
            ])),
            max_steps=int(c.get("max_steps", 50)),
            goal_kind=c.get("goal_kind"),
            goal_name=c.get("goal_name"),
            goal_min_score=float(c.get("goal_min_score", 0.75)),
            goal_allow_unmet=int(c.get("goal_allow_unmet", 0)),
        )

    def _setup_visualization_paths(self) -> None:
        """Configure paths for VPM visualization artifacts."""
        c = (self.cfg.get("vpm_control") or {})
        
        # Base directory for visualization artifacts
        self._viz_dir = c.get("viz_dir", "./runs/vpm_visualizations")
        os.makedirs(self._viz_dir, exist_ok=True)
        
        # Subdirectories for different visualization types
        self._raw_viz_dir = os.path.join(self._viz_dir, "raw")
        self._phos_viz_dir = os.path.join(self._viz_dir, "phos")
        self._compare_viz_dir = os.path.join(self._viz_dir, "comparison")
        
        os.makedirs(self._raw_viz_dir, exist_ok=True)
        os.makedirs(self._phos_viz_dir, exist_ok=True)
        os.makedirs(self._compare_viz_dir, exist_ok=True)
        
        # TL fractions for PHOS guard sweep
        self._tl_fracs = c.get("tl_fracs", [0.25, 0.16, 0.36, 0.09])
        self._delta = c.get("delta", 0.02)
        
        # Dimensions to visualize
        self._dimensions = c.get("dimensions", [
            "coverage", "correctness", "coherence", "citation_support", "entity_consistency"
        ])

    # ---------------- Service Protocol Implementation ----------------
    
    def initialize(self, **kwargs) -> None:
        """Initialize the service and required resources."""
        if self._initialized:
            return
            
        self._initialized = True
        self.logger.log("VPMControlServiceInit", {
            "viz_dir": self._viz_dir,
            "tl_fracs": self._tl_fracs,
            "delta": self._delta,
            "dimensions": self._dimensions
        })

    def shutdown(self) -> None:
        """Clean up resources and persist state if needed."""
        # Persist any remaining controller state
        for unit, controller in self._controllers.items():
            try:
                controller._persist_state()
            except Exception as e:
                self.logger.log("VPMControlServiceWarning", {
                    "event": "state_persist_failed",
                    "unit": unit,
                    "error": str(e)
                })
                
        self._controllers.clear()
        self._initialized = False
        self.logger.log("VPMControlServiceShutdown", {})

    def health_check(self) -> Dict[str, Any]:
        """Return service health status and metrics."""
        return {
            "status": "healthy" if self._initialized else "uninitialized",
            "units": len(self._controllers),
            "timestamp": time.time(),
            "viz_dir": self._viz_dir,
            "active_dimensions": self._dimensions
        }

    @property
    def name(self) -> str:
        """Service name for identification."""
        return "vpm-control-service"

    # ---------------- Public API ----------------
    
    def decide(
        self,
        unit: str,
        *,
        kind: str,
        dims: Dict[str, float],
        step_idx: Optional[int] = None,
        meta: Optional[Dict[str, Any]] = None,
        candidate_exemplars: Optional[List[str]] = None,
    ) -> Decision:
        """
        Make a VPM-based control decision for a processing unit.
        
        Args:
            unit: Identifier for the processing unit (e.g., question ID)
            kind: Type of processing ("text" or "code")
            dims: Performance metrics for the current state
            step_idx: Current step index in the processing pipeline
            meta: Additional metadata for decision context
            candidate_exemplars: Available exemplars for resampling
            
        Returns:
            Decision object with signal, reason, parameters, and snapshot
        """
        # Get or create controller for this unit
        ctrl = self._get_controller(unit)
        
        # Create VPM row for this state
        m = dict(meta or {})
        if candidate_exemplars:
            m["candidate_exemplars"] = candidate_exemplars
            
        row = VPMRow(
            unit=unit,
            kind=("code" if kind == "code" else "text"),
            timestamp=time.time(),
            step_idx=step_idx,
            dims={k: float(v) for k, v in dims.items()},
            meta=m,
        )
        
        # Track metrics history for visualization
        self._track_metrics(unit, dims, step_idx)
        
        # Make decision
        dec = ctrl.add(row, candidate_exemplars=candidate_exemplars)
        
        # Emit and persist decision
        self._publish(unit, dec)
        self._persist_trace(unit, row, dec)
        
        # Generate visualization if needed
        if step_idx is not None and step_idx % 5 == 0:  # Every 5 steps
            self.generate_visualization(unit, step_idx)
            
        return dec

    def decide_many(self, unit: str, frames: List[dict]) -> List[Decision]:
        """
        Process multiple metric frames for a single unit (batch processing).
        
        Args:
            unit: Identifier for the processing unit
            frames: List of metric frames to process
            
        Returns:
            List of decisions corresponding to each frame
        """
        out = []
        for f in frames:
            out.append(self.decide(
                unit,
                kind=f.get("kind", "text"),
                dims=f.get("dims", {}),
                step_idx=f.get("step_idx"),
                meta=f.get("meta"),
                candidate_exemplars=f.get("candidate_exemplars"),
            ))
        return out

    def reset_unit(self, unit: str) -> None:
        """Reset the controller state for a specific unit."""
        if unit in self._controllers:
            del self._controllers[unit]
            self.logger.log("VPMControlResetUnit", {"unit": unit})

    def get_unit_state(self, unit: str) -> Dict[str, Any]:
        """
        Get the current state of a unit's controller.
        
        Returns:
            Dictionary with controller state information
        """
        ctrl = self._controllers.get(unit)
        if not ctrl:
            return {}
            
        return {
            "resample_counts": dict(ctrl.resample_counts),
            "cooldown_until_step": dict(ctrl.cooldown_until_step),
            "last_signal": {k: v.name for k, v in ctrl.last_signal.items()},
        }

    def set_goal_gate(
        self, 
        *, 
        goal_kind: Optional[str], 
        goal_name: Optional[str],
        min_score: float = 0.75, 
        allow_unmet: int = 0
    ) -> None:
        """
        Update goal-aware parameters for all controllers.
        
        Args:
            goal_kind: Type of goal ("text" or "code")
            goal_name: Name of the specific goal
            min_score: Minimum score required to meet goal
            allow_unmet: Number of unmet dimensions allowed
        """
        self._policy.goal_kind = goal_kind
        self._policy.goal_name = goal_name
        self._policy.goal_min_score = float(min_score)
        self._policy.goal_allow_unmet = int(allow_unmet)
        
        # Update existing controllers
        for ctrl in self._controllers.values():
            ctrl.p = self._policy
            
        self.logger.log("VPMControlGoalGateUpdated", {
            "goal_kind": goal_kind,
            "goal_name": goal_name,
            "min_score": min_score,
            "allow_unmet": allow_unmet
        })

    def attach_bandit(
        self, 
        choose_fn: Callable[[List[str]], str], 
        update_fn: Callable[[str, float], None]
    ) -> None:
        """
        Attach bandit hooks for adaptive exemplar selection.
        
        Args:
            choose_fn: Function to select exemplar from candidates
            update_fn: Function to update bandit with reward
        """
        self._bandit_choose = choose_fn
        self._bandit_update = update_fn
        
        # Update existing controllers
        for ctrl in self._controllers.values():
            ctrl.bandit_choose = choose_fn
            ctrl.bandit_update = update_fn
            
        self.logger.log("VPMControlBanditAttached", {})

    def generate_visualization(
        self, 
        unit: str, 
        step_idx: Optional[int] = None,
        output_path: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Generate VPM visualization artifacts for a specific unit.
        
        Args:
            unit: Identifier for the processing unit
            step_idx: Current step index (for naming)
            output_path: Custom output path (defaults to configured viz_dir)
            
        Returns:
            Dictionary with paths to generated visualization artifacts
        """
        # Get metrics history for this unit
        metrics_history = self._metrics_history.get(unit, [])
        if not metrics_history:
            return {}
            
        # Convert to DataFrame format expected by VPM builder
        df = self._convert_to_dataframe(metrics_history)
        
        # Determine output path
        if output_path is None:
            output_path = os.path.join(self._phos_viz_dir, f"{unit.replace(':', '_')}")
            
        # Generate PHOS artifacts
        artifacts = build_vpm_phos_artifacts(
            df,
            model="ssp",
            dimensions=self._dimensions,
            out_prefix=output_path,
            tl_frac=0.25,  # Default for single visualization
            interleave=False,
            weights=None,
        )
        
        # Generate comparison artifacts if we have multiple models (for future extension)
        # This would require tracking multiple models' performance
        
        return {
            "raw": artifacts["paths"]["raw"],
            "phos": artifacts["paths"]["phos"],
            "metrics": json.dumps(artifacts["metrics"]),
        }

    def generate_comparison_visualization(
        self,
        unit: str,
        model_a: str,
        model_b: str,
        output_path: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Generate comparison visualization between two models for a unit.
        
        Args:
            unit: Identifier for the processing unit
            model_a: First model identifier
            model_b: Second model identifier
            output_path: Custom output path
            
        Returns:
            Dictionary with paths to generated comparison artifacts
        """
        # This would be implemented when comparing different SSP configurations
        # For now, it's a placeholder for future extension
        if output_path is None:
            output_path = os.path.join(
                self._compare_viz_dir, 
                f"{unit.replace(':', '_')}_{model_a}_vs_{model_b}"
            )
            
        # In a real implementation, we would:
        # 1. Gather metrics for both models
        # 2. Build a DataFrame with both models' performance
        # 3. Call build_compare_guarded
        
        # Placeholder implementation
        return {
            "message": "Comparison visualization not yet implemented for this service"
        }

    # ---------------- Internal Helpers ----------------
    
    def _get_controller(self, unit: str) -> CoreVPMController:
        """Get or create a VPM controller for the specified unit."""
        if unit not in self._controllers:
            # Create state path for this unit
            state_path = os.path.join(
                self._viz_dir, 
                f"vpm_state_{unit.replace(':', '_')}.json"
            )
            
            # Create controller
            ctrl = CoreVPMController(
                thresholds_code=self._thr_code,
                thresholds_text=self._thr_text,
                policy=self._policy,
                bandit_choose=self._bandit_choose,
                bandit_update=self._bandit_update,
                logger=lambda ev, d: self.logger.log(ev, d),
                state_path=state_path,
            )
            
            self._controllers[unit] = ctrl
            
        return self._controllers[unit]

    def _publish(self, unit: str, dec: Decision) -> None:
        """Publish decision to event bus if available."""
        try:
            if self._bus and hasattr(self._bus, "publish"):
                self._bus.publish("vpm.control.decision", {
                    "unit": unit, 
                    **asdict(dec)
                })
        except Exception as e:
            self.logger.log("VPMControlServiceWarning", {
                "event": "publish_failed",
                "unit": unit,
                "error": str(e)
            })

    def _persist_trace(self, unit: str, row: VPMRow, dec: Decision) -> None:
        """Persist decision trace to memory storage."""
        try:
            repo = getattr(self.memory, "plan_traces", None) or getattr(self.memory, "traces", None)
            if repo and hasattr(repo, "insert"):
                repo.insert({
                    "ts": time.time(),
                    "kind": "vpm_control_decision",
                    "unit": unit,
                    "signal": dec.signal.name,
                    "reason": dec.reason,
                    "params": dec.params,
                    "snapshot": dec.snapshot,
                    "metrics": row.dims,
                    "step_idx": row.step_idx,
                })
        except Exception as e:
            self.logger.log("VPMControlServiceWarning", {
                "event": "trace_persist_failed",
                "unit": unit,
                "error": str(e)
            })

    def _track_metrics(
        self, 
        unit: str, 
        dims: Dict[str, float], 
        step_idx: Optional[int]
    ) -> None:
        """Track metrics history for visualization purposes."""
        if unit not in self._metrics_history:
            self._metrics_history[unit] = []
            
        # Create a record with step index and metrics
        record = {
            "step_idx": step_idx or len(self._metrics_history[unit]),
            **{k: float(v) for k, v in dims.items()}
        }
        
        self._metrics_history[unit].append(record)
        
        # Keep history bounded
        max_history = self.cfg.get("vpm_control", {}).get("max_metrics_history", 100)
        if len(self._metrics_history[unit]) > max_history:
            self._metrics_history[unit] = self._metrics_history[unit][-max_history:]

    def _convert_to_dataframe(self, metrics_history: List[Dict]) -> Any:
        """
        Convert metrics history to DataFrame format expected by VPM builder.
        
        In a real implementation, this would create a proper pandas DataFrame.
        For this example, we'll create a simplified structure that matches expectations.
        """
        try:
            import pandas as pd
            # Create a DataFrame with multi-index for model and dimension
            df_data = []
            for record in metrics_history:
                step_idx = record["step_idx"]
                for dim, value in record.items():
                    if dim == "step_idx":
                        continue
                    df_data.append({
                        "node_id": f"{step_idx}",
                        "ssp": value,
                        "dimension": dim
                    })
            
            df = pd.DataFrame(df_data)
            # Pivot to get dimensions as columns
            df = df.pivot(index="node_id", columns="dimension", values="ssp").reset_index()
            return df
        except ImportError:
            # Fallback for environments without pandas
            # This would be a minimal implementation just for the example
            return {
                "node_id": [str(i) for i in range(len(metrics_history))],
                **{dim: [] for dim in self._dimensions}
            }

    # ---------------- Debugging ----------------
    
    def __repr__(self):
        """String representation for debugging."""
        active_count = len(self._controllers)
        return (
            f"<VPMControlService: status={'initialized' if self._initialized else 'uninitialized'}  "
            f"units={active_count}  "
            f"dimensions={len(self._dimensions)}>"
        )
``n

## File: services\vpm_visualization_service.py

`python
# stephanie/components/ssp/services/vpm_visualization_service.py
"""
VPM Visualization Service - Generates Vectorized Performance Map images for SSP episodes

This service converts SSP episode data into VPM visualizations that help track:
- Performance trends across multiple dimensions
- Difficulty progression in the curriculum
- Evidence quality and solver efficiency
- Verification success patterns

The service uses the PHOS (Packed High-Order Structure) algorithm to create 
meaningful visual representations of multi-dimensional performance metrics.

Key features:
- Generates both raw VPM and PHOS-packed visualizations
- Creates comparison visualizations between different SSP configurations
- Tracks historical trends for curriculum management
- Integrates with the VPM control system for decision support
- Configurable visualization styles and parameters
"""

from __future__ import annotations

import os
import time
import json
import logging
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from stephanie.logging.json_logger import JSONLogger
from stephanie.memory.memory_tool import MemoryTool
from stephanie.services.service_protocol import Service
from stephanie.components.ssp.utils.trace import EpisodeTrace

# Import VPM visualization components from the examples provided
from stephanie.zeromodel.vpm_phos import (
    build_vpm_phos_artifacts,
    build_compare_guarded,
    robust01,
    brightness_concentration,
    image_entropy,
    save_img,
    vpm_vector_from_df,
    to_square,
    phos_sort_pack
)
from stephanie.zeromodel.vpm_controller import VPMRow, Signal, Thresholds, Policy

class VPMVisualizationService(Service):
    """
    Service for generating VPM visualization artifacts from SSP episode data.
    
    This service:
    - Converts EpisodeTrace objects to VPM-compatible metric formats
    - Generates both raw VPM and PHOS-packed visualizations
    - Creates comparison visualizations between different SSP configurations
    - Tracks historical trends for curriculum management
    - Integrates with the VPM control system for decision support
    
    The service follows a stateful pattern where each processing unit (e.g., question, episode)
    has its own controller instance that tracks its performance history.
    """
    
    def __init__(
        self, 
        cfg: Dict[str, Any], 
        memory: MemoryTool, 
        logger: JSONLogger, 
        container: Optional[Any] = None
    ):
        """
        Initialize the VPM Visualization Service.
        
        Args:
            cfg: Configuration dictionary with VPM parameters
            memory: Memory tool for state persistence
            logger: JSON logger for structured logging
            container: Dependency injection container
        """
        self.cfg = cfg or {}
        self.memory = memory
        self.logger = logger
        self.container = container
        self._initialized = False

        # Service state
        self._metrics_history: Dict[str, List[Dict[str, float]]] = {}
        self._episode_traces: Dict[str, EpisodeTrace] = {}
        
        # Visualization configuration
        self._setup_visualization_paths()
        
        # Metrics configuration
        self._setup_metrics()
        
        # VPM parameters
        self._setup_vpm_parameters()

    def _setup_visualization_paths(self) -> None:
        """Configure paths for VPM visualization artifacts."""
        c = (self.cfg.get("vpm_viz") or {})
        
        # Base directory for visualization artifacts
        self._viz_dir = c.get("output_dir", "./runs/vpm_visualizations")
        os.makedirs(self._viz_dir, exist_ok=True)
        
        # Subdirectories for different visualization types
        self._raw_viz_dir = os.path.join(self._viz_dir, "raw")
        self._phos_viz_dir = os.path.join(self._viz_dir, "phos")
        self._compare_viz_dir = os.path.join(self._viz_dir, "comparison")
        self._episode_data_dir = os.path.join(self._viz_dir, "episode_data")
        
        os.makedirs(self._raw_viz_dir, exist_ok=True)
        os.makedirs(self._phos_viz_dir, exist_ok=True)
        os.makedirs(self._compare_viz_dir, exist_ok=True)
        os.makedirs(self._episode_data_dir, exist_ok=True)
        
        # TL fractions for PHOS guard sweep
        self._tl_fracs = c.get("tl_fracs", [0.25, 0.16, 0.36, 0.09])
        self._delta = c.get("delta", 0.02)
        
        # Dimensions to visualize
        self._dimensions = c.get("dimensions", [
            "verifier_f1", "difficulty", "steps_norm", "evidence_cnt",
            "coverage", "correctness", "coherence", "citation_support", "entity_consistency"
        ])

    def _setup_metrics(self) -> None:
        """Configure metrics conversion and normalization parameters."""
        # Default metric ranges for normalization
        self._metric_ranges = {
            "verifier_f1": (0.0, 1.0),
            "difficulty": (0.0, 1.0),
            "steps_norm": (0.0, 1.0),
            "evidence_cnt": (0.0, 1.0),
            "coverage": (0.0, 1.0),
            "correctness": (0.0, 1.0),
            "coherence": (0.0, 1.0),
            "citation_support": (0.0, 1.0),
            "entity_consistency": (0.0, 1.0)
        }
        
        # Override with config values if provided
        metric_cfg = self.cfg.get("vpm_viz", {}).get("metric_ranges", {})
        for metric, (min_val, max_val) in metric_cfg.items():
            if metric in self._metric_ranges:
                self._metric_ranges[metric] = (float(min_val), float(max_val))

    def _setup_vpm_parameters(self) -> None:
        """Configure VPM-specific parameters for visualization generation."""
        c = (self.cfg.get("vpm_viz") or {})
        
        # PHOS parameters
        self._phos_tl_frac = float(c.get("phos_tl_frac", 0.25))
        self._phos_interleave = bool(c.get("phos_interleave", False))
        self._phos_weights = c.get("phos_weights", None)
        
        # Raw VPM parameters
        self._raw_vpm_interleave = bool(c.get("raw_vpm_interleave", False))
        self._raw_vpm_weights = c.get("raw_vpm_weights", None)
        
        # Comparison parameters
        self._compare_models = c.get("compare_models", ["current", "baseline"])
        self._compare_tl_fracs = c.get("compare_tl_fracs", self._tl_fracs)
        self._compare_delta = float(c.get("compare_delta", self._delta))

    # ---------------- Service Protocol Implementation ----------------
    
    def initialize(self, **kwargs) -> None:
        """Initialize the service and required resources."""
        if self._initialized:
            return
            
        self._initialized = True
        self.logger.log("VPMVisualizationServiceInit", {
            "viz_dir": self._viz_dir,
            "tl_fracs": self._tl_fracs,
            "delta": self._delta,
            "dimensions": self._dimensions,
            "metric_ranges": self._metric_ranges
        })

    def shutdown(self) -> None:
        """Clean up resources and persist state if needed."""
        # Clear internal caches
        self._metrics_history.clear()
        self._episode_traces.clear()
        
        self._initialized = False
        self.logger.log("VPMVisualizationServiceShutdown", {})

    def health_check(self) -> Dict[str, Any]:
        """Return service health status and metrics."""
        return {
            "status": "healthy" if self._initialized else "uninitialized",
            "episode_count": len(self._episode_traces),
            "traced_dimensions": len(self._metrics_history),
            "timestamp": time.time(),
            "viz_dir": self._viz_dir,
            "active_dimensions": self._dimensions
        }

    @property
    def name(self) -> str:
        """Service name for identification."""
        return "ssp-vpm-visualization"

    # ---------------- Public API ----------------
    
    def generate_episode_visualization(
        self, 
        unit: str,
        episode: EpisodeTrace,
        step_idx: Optional[int] = None,
        output_path: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Generate VPM visualization artifacts for a specific SSP episode.
        
        Args:
            unit: Identifier for the processing unit (e.g., question ID)
            episode: EpisodeTrace object containing the episode data
            step_idx: Current step index in the processing pipeline
            output_path: Custom output path (defaults to configured viz_dir)
            
        Returns:
            Dictionary with paths to generated visualization artifacts
        """
        # Store episode trace for potential comparison
        self._episode_traces[unit] = episode
        
        # Convert episode to VPM row and track metrics
        vpm_row = self._episode_to_vpm_row(unit, episode, step_idx)
        self._track_metrics(unit, vpm_row, step_idx)
        
        # Generate visualization
        return self.generate_visualization(
            unit=unit,
            step_idx=step_idx,
            output_path=output_path
        )

    def generate_visualization(
        self, 
        unit: str, 
        step_idx: Optional[int] = None,
        output_path: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Generate VPM visualization artifacts for a specific unit.
        
        Args:
            unit: Identifier for the processing unit
            step_idx: Current step index (for naming)
            output_path: Custom output path (defaults to configured viz_dir)
            
        Returns:
            Dictionary with paths to generated visualization artifacts
        """
        # Get metrics history for this unit
        metrics_history = self._metrics_history.get(unit, [])
        if not metrics_history:
            return {}
            
        # Convert to DataFrame format expected by VPM builder
        df = self._convert_to_dataframe(metrics_history)
        
        # Determine output path
        if output_path is None:
            output_path = os.path.join(self._phos_viz_dir, f"{unit.replace(':', '_')}")
            
        # Generate PHOS artifacts
        artifacts = build_vpm_phos_artifacts(
            df,
            model="ssp",
            dimensions=self._dimensions,
            out_prefix=output_path,
            tl_frac=self._phos_tl_frac,
            interleave=self._phos_interleave,
            weights=self._phos_weights,
        )
        
        # Generate raw VPM as well
        raw_output_path = output_path.replace(self._phos_viz_dir, self._raw_viz_dir)
        raw_artifacts = build_vpm_phos_artifacts(
            df,
            model="ssp",
            dimensions=self._dimensions,
            out_prefix=raw_output_path,
            tl_frac=0.0,  # Raw VPM doesn't need PHOS packing
            interleave=self._raw_vpm_interleave,
            weights=self._raw_vpm_weights,
        )
        
        # Save episode data for future reference
        self._save_episode_data(unit, metrics_history, output_path)
        
        return {
            "raw": raw_artifacts["paths"]["raw"],
            "phos": artifacts["paths"]["phos"],
            "metrics": json.dumps(artifacts["metrics"]),
            "episode_data": os.path.join(self._episode_data_dir, f"{unit}.json")
        }

    def generate_comparison_visualization(
        self,
        unit: str,
        model_a: str,
        model_b: str,
        output_path: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Generate comparison visualization between two models for a unit.
        
        Args:
            unit: Identifier for the processing unit
            model_a: First model identifier
            model_b: Second model identifier
            output_path: Custom output path
            
        Returns:
            Dictionary with paths to generated comparison artifacts
        """
        # Determine output path
        if output_path is None:
            output_path = os.path.join(
                self._compare_viz_dir, 
                f"{unit.replace(':', '_')}_{model_a}_vs_{model_b}"
            )
            
        # Generate comparison artifacts
        artifacts = build_compare_guarded(
            df=self._get_comparison_dataframe(unit, model_a, model_b),
            dimensions=self._dimensions,
            out_prefix=output_path,
            model_A=model_a,
            model_B=model_b,
            tl_fracs=self._compare_tl_fracs,
            delta=self._compare_delta,
            interleave=self._phos_interleave,
            weights=self._phos_weights,
        )
        
        return {
            "summary": artifacts.get("summary", {}),
            "sweep": artifacts.get("sweep", {}),
            "diff_range": artifacts.get("diff_range"),
            "diff_image": f"{output_path}_vpm_chosen_diff.png",
            "model_a_chosen": artifacts["sweep"].get(model_a, [{}])[-1].get("phos_path", ""),
            "model_b_chosen": artifacts["sweep"].get(model_b, [{}])[-1].get("phos_path", "")
        }

    def generate_curriculum_visualization(
        self,
        output_path: Optional[str] = None
    ) -> Dict[str, str]:
        """
        Generate visualization showing curriculum progression over time.
        
        Args:
            output_path: Custom output path
            
        Returns:
            Dictionary with paths to generated visualization artifacts
        """
        # Aggregate metrics across all units
        all_metrics = []
        for unit, metrics in self._metrics_history.items():
            for metric in metrics:
                all_metrics.append({
                    "unit": unit,
                    **metric
                })
        
        if not all_metrics:
            return {}
            
        # Create DataFrame
        df = pd.DataFrame(all_metrics)
        
        # Create a special curriculum-focused output path
        if output_path is None:
            timestamp = int(time.time())
            output_path = os.path.join(self._phos_viz_dir, f"curriculum_progression_{timestamp}")
            
        # Generate PHOS artifacts
        artifacts = build_vpm_phos_artifacts(
            df,
            model="curriculum",
            dimensions=self._dimensions,
            out_prefix=output_path,
            tl_frac=self._phos_tl_frac,
            interleave=self._phos_interleave,
            weights=self._phos_weights,
        )
        
        return {
            "curriculum_phos": artifacts["paths"]["phos"],
            "curriculum_raw": artifacts["paths"]["raw"],
            "metrics": json.dumps(artifacts["metrics"]),
        }

    # ---------------- Internal Helpers ----------------
    
    def _episode_to_vpm_row(
        self, 
        unit: str,
        episode: EpisodeTrace, 
        step_idx: Optional[int] = None
    ) -> VPMRow:
        """
        Convert an EpisodeTrace to a VPMRow for visualization.
        
        Args:
            unit: Identifier for the processing unit
            episode: EpisodeTrace object
            step_idx: Current step index
            
        Returns:
            VPMRow object compatible with visualization pipeline
        """
        # Convert episode to metrics
        dims = self.episode_to_dims(episode)
        
        # Create VPMRow
        return VPMRow(
            unit=unit,
            kind="text",  # SSP is primarily text processing
            timestamp=time.time(),
            step_idx=step_idx,
            dims=dims,
            meta={
                "episode_id": episode.episode_id,
                "verified": episode.verified,
                "question": episode.question,
                "predicted_answer": episode.predicted_answer,
                "solver_steps": episode.solver_steps,
                "evidence_count": len(episode.evidence_docs),
                "difficulty": episode.difficulty
            }
        )

    def episode_to_dims(self, ep: EpisodeTrace) -> Dict[str, float]:
        """
        Normalize episode metrics into [0,1] ranges for visualization.
        
        Args:
            ep: EpisodeTrace object
            
        Returns:
            Dictionary of normalized metrics
        """
        # Normalize simple dims into [0,1] where sensible
        dims = {
            "verifier_f1": float(ep.reward),  # already 0..1-ish with F1
            "difficulty": float(ep.difficulty),  # assume 0..1 curriculum
            "steps_norm": min(1.0, ep.solver_steps / 16.0),  # clip to a small bound
            "evidence_cnt": min(1.0, len(ep.evidence_docs) / 8.0),
        }
        
        # Add any additional metrics from meta if present
        if hasattr(ep, 'meta') and isinstance(ep.meta, dict):
            # Coverage - assume it's in the meta
            if 'coverage' in ep.meta:
                dims['coverage'] = min(1.0, max(0.0, float(ep.meta['coverage'])))
            
            # Correctness - assume it's in the meta
            if 'correctness' in ep.meta:
                dims['correctness'] = min(1.0, max(0.0, float(ep.meta['correctness'])))
            
            # Coherence - assume it's in the meta
            if 'coherence' in ep.meta:
                dims['coherence'] = min(1.0, max(0.0, float(ep.meta['coherence'])))
            
            # Citation support - assume it's in the meta
            if 'citation_support' in ep.meta:
                dims['citation_support'] = min(1.0, max(0.0, float(ep.meta['citation_support'])))
            
            # Entity consistency - assume it's in the meta
            if 'entity_consistency' in ep.meta:
                dims['entity_consistency'] = min(1.0, max(0.0, float(ep.meta['entity_consistency'])))
        
        # Ensure all required dimensions have values
        for dim in self._dimensions:
            if dim not in dims:
                dims[dim] = 0.0
                
        return dims

    def _track_metrics(
        self, 
        unit: str, 
        vpm_row: VPMRow, 
        step_idx: Optional[int]
    ) -> None:
        """Track metrics history for visualization purposes."""
        if unit not in self._metrics_history:
            self._metrics_history[unit] = []
            
        # Create a record with step index and metrics
        record = {
            "step_idx": step_idx or len(self._metrics_history[unit]),
            **{k: float(v) for k, v in vpm_row.dims.items()}
        }
        
        self._metrics_history[unit].append(record)
        
        # Keep history bounded
        max_history = self.cfg.get("vpm_viz", {}).get("max_metrics_history", 100)
        if len(self._metrics_history[unit]) > max_history:
            self._metrics_history[unit] = self._metrics_history[unit][-max_history:]

    def _convert_to_dataframe(self, metrics_history: List[Dict]) -> pd.DataFrame:
        """
        Convert metrics history to DataFrame format expected by VPM builder.
        """
        try:
            # Create a DataFrame with multi-index for model and dimension
            df_data = []
            for i, record in enumerate(metrics_history):
                step_idx = record["step_idx"]
                for dim, value in record.items():
                    if dim == "step_idx":
                        continue
                    df_data.append({
                        "node_id": f"{step_idx}",
                        "ssp": value,
                        "dimension": dim
                    })
            
            df = pd.DataFrame(df_data)
            # Pivot to get dimensions as columns
            df = df.pivot(index="node_id", columns="dimension", values="ssp").reset_index()
            
            # Ensure all dimensions are present
            for dim in self._dimensions:
                if dim not in df.columns:
                    df[dim] = 0.0
            
            return df
        except Exception as e:
            self.logger.log("VPMVisualizationError", {
                "event": "dataframe_conversion_failed",
                "error": str(e)
            })
            # Fallback for environments without pandas
            return pd.DataFrame({
                "node_id": [str(i) for i in range(len(metrics_history))],
                **{dim: [0.0] * len(metrics_history) for dim in self._dimensions}
            })

    def _get_comparison_dataframe(
        self, 
        unit: str, 
        model_a: str, 
        model_b: str
    ) -> pd.DataFrame:
        """
        Create a DataFrame suitable for model comparison visualization.
        """
        # Get metrics for both models
        model_a_metrics = self._get_model_metrics(unit, model_a)
        model_b_metrics = self._get_model_metrics(unit, model_b)
        
        # Convert to DataFrames
        df_a = self._convert_to_dataframe(model_a_metrics)
        df_b = self._convert_to_dataframe(model_b_metrics)
        
        # Merge DataFrames
        df = df_a.merge(df_b, on="node_id", suffixes=("_a", "_b"))
        
        # Rename columns to match expected format
        for dim in self._dimensions:
            if f"{dim}_a" in df.columns and f"{dim}_b" in df.columns:
                df[f"{model_a}.{dim}"] = df[f"{dim}_a"]
                df[f"{model_b}.{dim}"] = df[f"{dim}_b"]
                df.drop([f"{dim}_a", f"{dim}_b"], axis=1, inplace=True)
                
        return df

    def _get_model_metrics(self, unit: str, model: str) -> List[Dict]:
        """
        Get metrics for a specific model.
        """
        if model == "current" and unit in self._metrics_history:
            return self._metrics_history[unit]
            
        # For baseline or other models, you would need to implement retrieval logic
        # This is a placeholder for actual implementation
        return []
        
    def _save_episode_data(self, unit: str, metrics_history: List[Dict], output_path: str) -> None:
        """
        Save episode data for future reference and analysis.
        """
        try:
            # Get the latest episode trace
            episode = self._episode_traces.get(unit)
            if not episode:
                return
                
            # Create episode data dictionary
            episode_data = {
                "unit": unit,
                "episode_id": episode.episode_id,
                "seed_answer": episode.seed_answer,
                "question": episode.question,
                "predicted_answer": episode.predicted_answer,
                "verified": episode.verified,
                "reward": episode.reward,
                "difficulty": episode.difficulty,
                "solver_steps": episode.solver_steps,
                "evidence_docs": episode.evidence_docs,
                "meta": episode.meta,
                "metrics_history": metrics_history
            }
            
            # Save to JSON
            data_path = os.path.join(self._episode_data_dir, f"{unit.replace(':', '_')}.json")
            with open(data_path, "w", encoding="utf-8") as f:
                json.dump(episode_data, f, indent=2, default=str)
                
        except Exception as e:
            self.logger.log("VPMVisualizationError", {
                "event": "episode_data_save_failed",
                "unit": unit,
                "error": str(e)
            })

    def generate_raw_vpm_image(
        self, 
        unit: str,
        step_idx: Optional[int] = None,
        output_path: Optional[str] = None
    ) -> str:
        """
        Generate a raw VPM image (without PHOS packing) for a specific unit.
        
        Args:
            unit: Identifier for the processing unit
            step_idx: Current step index
            output_path: Custom output path
            
        Returns:
            Path to the generated image
        """
        # Get metrics history for this unit
        metrics_history = self._metrics_history.get(unit, [])
        if not metrics_history:
            return ""
            
        # Convert to VPM vector
        df = self._convert_to_dataframe(metrics_history)
        vec = vpm_vector_from_df(
            df,
            model="ssp",
            dimensions=self._dimensions,
            interleave=self._raw_vpm_interleave,
            weights=self._raw_vpm_weights
        )
        
        # Convert to square image
        img, _ = to_square(vec)
        
        # Save image
        if output_path is None:
            output_path = os.path.join(
                self._raw_viz_dir, 
                f"{unit.replace(':', '_')}_raw_vpm_{int(time.time())}.png"
            )
            
        save_img(img, output_path, title=f"SSP VPM (Raw) - {unit}")
        
        return output_path

    def generate_phos_image(
        self, 
        unit: str,
        step_idx: Optional[int] = None,
        output_path: Optional[str] = None,
        tl_frac: Optional[float] = None
    ) -> str:
        """
        Generate a PHOS-packed VPM image for a specific unit.
        
        Args:
            unit: Identifier for the processing unit
            step_idx: Current step index
            output_path: Custom output path
            tl_frac: Top-left fraction for PHOS packing
            
        Returns:
            Path to the generated image
        """
        # Get metrics history for this unit
        metrics_history = self._metrics_history.get(unit, [])
        if not metrics_history:
            return ""
            
        # Convert to VPM vector
        df = self._convert_to_dataframe(metrics_history)
        vec = vpm_vector_from_df(
            df,
            model="ssp",
            dimensions=self._dimensions,
            interleave=self._phos_interleave,
            weights=self._phos_weights
        )
        
        # Apply PHOS packing
        tl_frac = tl_frac if tl_frac is not None else self._phos_tl_frac
        img = phos_sort_pack(vec, tl_frac=tl_frac)
        
        # Save image
        if output_path is None:
            output_path = os.path.join(
                self._phos_viz_dir, 
                f"{unit.replace(':', '_')}_phos_vpm_{int(time.time())}.png"
            )
            
        save_img(img, output_path, title=f"SSP VPM (PHOS) - {unit}")
        
        return output_path

    # ---------------- Debugging ----------------
    
    def __repr__(self):
        """String representation for debugging."""
        episode_count = len(self._episode_traces)
        return (
            f"<VPMVisualizationService: status={'initialized' if self._initialized else 'uninitialized'}  "
            f"episodes={episode_count}  "
            f"dimensions={len(self._dimensions)}>"
        ) 
``n

## File: training\rewards.py

`python
"""
Self-Play Rewards Calculation

This module implements the reward calculation logic for the
SSP self-play dynamics as described in the paper:

- Solver reward: accuracy on verified questions (cooperative)
- Proposer reward: 1 - solver accuracy (adversarial)
"""

from typing import List, Dict, Any

from stephanie.components.ssp.utils.trace import EpisodeTrace


def calculate_self_play_rewards(
    verified_episodes: List[EpisodeTrace],
    unverified_count: int
) -> Dict[str, float]:
    """
    Calculate rewards for both proposer and solver based on episode outcomes.
    
    Args:
        verified_episodes: List of successfully verified episodes
        unverified_count: Number of episodes that failed verification
        
    Returns:
        Dictionary with proposer_reward and solver_reward
    """
    total = len(verified_episodes) + unverified_count
    
    if total == 0:
        return {"proposer_reward": 0.0, "solver_reward": 0.0}
    
    # Solver reward: accuracy on verified questions
    solver_success = sum(1 for ep in verified_episodes if ep.verified) / len(verified_episodes) if verified_episodes else 0.0
    
    # Proposer reward: adversarial (1 - solver accuracy) with novelty bonus
    proposer_reward = (1.0 - solver_success) + (unverified_count / total * 0.1)
    
    return {
        "solver_reward": solver_success,
        "proposer_reward": min(proposer_reward, 1.5),  # Cap at 1.5
        "solver_success_rate": solver_success,
        "acceptance_rate": len(verified_episodes) / total,
        "unverified_rate": unverified_count / total
    }


def update_episode_with_rewards(
    episode: EpisodeTrace,
    solver_reward: float,
    proposer_reward: float
) -> None:
    """
    Update an episode trace with reward information.
    
    Args:
        episode: Episode to update
        solver_reward: Solver's reward for this episode
        proposer_reward: Proposer's reward for this episode
    """
    episode.solver_reward = solver_reward
    episode.proposer_reward = proposer_reward
    episode.verifier_meta["solver_reward"] = solver_reward
    episode.proposer_meta["proposer_reward"] = proposer_reward
``n

## File: training\trainer.py

`python
# stephanie/components/ssp/trainer.py
from __future__ import annotations
import time
import uuid
from typing import Any, Dict, Iterable

from stephanie.components.ssp.utils.trace import EpisodeTrace
from stephanie.components.ssp.impl.proposers.searching_proposer import SearchingProposer
from stephanie.components.ssp.impl.solvers.ats_solver import ATSSolver
from stephanie.components.ssp.impl.solvers.solution_search import SolutionSearch
from stephanie.components.ssp.impl.verifiers.f1_verifier import Verifier
from stephanie.components.tree.events import TreeEventEmitter

class Trainer:
    def __init__(self, cfg, memory, container, logger):
        self.cfg =cfg
        self.memory = memory
        self.container = container
        self.logger = logger
        self.difficulty = cfg.get("difficulty", 0.3)
        self.verify = Verifier(cfg=self.cfg, memory=self.memory, container=self.container, logger=self.logger)

    async def run_episode(self, seed_answer: str, context: Dict[str, Any]) -> EpisodeTrace:
        episode_id = f"ssp-{int(time.time()*1000)}-{uuid.uuid4().hex[:6]}"
        emitter = TreeEventEmitter(topic="ssp.ats")
        solution_search = SolutionSearch(cfg=self.cfg, memory=self.memory, container=self.container, logger=self.logger, event_emitter=emitter)
        proposer = SearchingProposer(self.cfg, memory=self.memory, container=self.container, logger=self.logger, solution_search=solution_search)
        question, evidence_snippets, meta = await proposer.propose(seed_answer, context=context)

        # ATS‑based solver with a tiny local searcher that contains the answer in synthetic docs
        solver = ATSSolver(cfg=self.cfg, memory=self.memory, container=self.container, logger=self.logger,
            searcher=solution_search, event_emitter=emitter)
        predicted, evidence, steps = await solver.solve(question, seed_answer=seed_answer, context=context, evidence_snippets=evidence_snippets)

        ok, reward = self.verify.verify(ground_truth=seed_answer, predicted=predicted)

        return EpisodeTrace(
            episode_id=episode_id,
            seed_answer=seed_answer,
            question=question,
            predicted_answer=predicted,
            verified=ok,
            reward=reward,
            difficulty=self.difficulty,
            solver_steps=steps,
            evidence_docs=evidence,
            meta={},
        )

    async def run_batch(self, seeds: Iterable[str], context: Dict[str, Any]) -> Dict[str, float]:
        n, r_sum, ok_sum = 0, 0.0, 0
        for s in seeds:
            ep = await self.run_episode(s, context)
            n += 1
            r_sum += ep.reward
            ok_sum += int(ep.verified)
            print(
                f"EP {ep.episode_id} | ok={ep.verified} r={ep.reward:.3f} | Q: {ep.question}\n"
                f"→ A*: {ep.predicted_answer}\n"
            )
        return {
            "episodes": n,
            "avg_reward": (r_sum / n) if n else 0.0,
            "success_rate": (ok_sum / n) if n else 0.0,
        }
``n

## File: types.py

`python
# stephanie/components/ssp/types.py
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass(slots=True)
class Proposal:
    # ❗ Non-defaults first
    query: str
    # defaults after
    difficulty: float = 0.30
    novelty: float = 0.0
    meta: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_any(cls, x: Any) -> "Proposal":
        """
        Accepts Proposal | dict | (query, difficulty) | [query, difficulty].
        """
        if isinstance(x, Proposal):
            return x
        if isinstance(x, dict):
            # tolerate alternate keys
            q = x.get("query") or x.get("question") or x.get("prompt") or ""
            return cls(
                query=q,
                difficulty=float(x.get("difficulty", 0.30)),
                novelty=float(x.get("novelty", 0.0)),
                meta=dict(x.get("meta", {})),
            )
        if isinstance(x, (list, tuple)) and x:
            q = str(x[0])
            d = float(x[1]) if len(x) > 1 else 0.30
            return cls(query=q, difficulty=d)
        # last resort
        return cls(query=str(x), difficulty=0.30)


@dataclass(slots=True)
class Solution:
    # all defaults → order is fine
    answer: str = ""
    evidence: List[str] = field(default_factory=list)
    reasoning_path: List[str] = field(default_factory=list)
    training_batch: Optional[Dict[str, Any]] = None
    meta: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_any(cls, x: Any) -> "Solution":
        if isinstance(x, Solution):
            return x
        if isinstance(x, dict):
            return cls(
                answer=x.get("answer", "") or x.get("text", "") or "",
                evidence=list(x.get("evidence", []) or []),
                reasoning_path=list(x.get("reasoning_path", []) or []),
                training_batch=x.get("training_batch"),
                meta=dict(x.get("meta", {})),
            )
        return cls(answer=str(x))


@dataclass(slots=True)
class Verification:
    # ❗ Non-defaults first
    is_valid: bool
    score: float
    # defaults after
    dimension_scores: Dict[str, float] = field(default_factory=dict)
    evidence_count: int = 0
    reasoning_steps: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
``n

## File: utils\filters.py

`python
"""
Rule-Based Filters for SSP

This module implements the rule-based filters required before
RAG-gated verification, as specified in the SSP paper.
"""

import re
from typing import List


def check_question_length(question: str, min_length: int = 20) -> bool:
    """Check if question meets minimum length requirement."""
    return len(question.strip()) >= min_length


def check_answer_leakage(question: str, seed_answer: str) -> bool:
    """
    Check if the question contains the seed answer (answer leakage).
    
    Returns True if leakage is detected (which means the filter fails).
    """
    # Normalize strings
    q_norm = re.sub(r'[^\w\s]', '', question.lower())
    ans_norm = re.sub(r'[^\w\s]', '', seed_answer.lower())
    
    # Check for direct inclusion
    if ans_norm in q_norm:
        return True
    
    # Check for word-by-word inclusion (more robust)
    ans_words = set(ans_norm.split())
    q_words = set(q_norm.split())
    
    # If more than 50% of answer words appear in question, consider it leakage
    if ans_words and (len(ans_words & q_words) / len(ans_words)) > 0.5:
        return True
    
    return False


def check_evidence_usage(evidence_snippets: List[str], min_count: int = 1) -> bool:
    """Check if sufficient evidence snippets were gathered."""
    return len(evidence_snippets) >= min_count


def check_tool_usage(evidence_snippets: List[str]) -> bool:
    """Check if evidence comes from actual tool usage (not empty)."""
    return bool(evidence_snippets) and any(snippet.strip() for snippet in evidence_snippets)


def check_format(question: str) -> bool:
    """Check if question is properly formatted."""
    # Must end with question mark
    if not question.strip().endswith('?'):
        return False
    
    # Must not be all caps
    if question.isupper():
        return False
    
    # Must not contain prompt injection patterns
    injection_patterns = [
        r"ignore\s+previous",
        r"forget\s+all",
        r"system\s+prompt",
        r"role\s+play",
        r"disregard\s+instructions"
    ]
    
    for pattern in injection_patterns:
        if re.search(pattern, question, re.IGNORECASE):
            return False
    
    return True
``n

## File: utils\parser.py

`python
"""
Parser Utilities for SSP Components

This module provides robust parsing functions for handling LLM responses
in the SSP system, with special attention to the proposer's output format.
"""

import re
from typing import Any, Dict, List, Optional, Pattern


# Regular expression to match key-value pairs in proposer responses
_LINE_RE: Pattern = re.compile(
    r'^\s*"?(?P<key>[A-Za-z_]+)"?\s*[:=]\s*(?P<value>.+?)\s*,?\s*$'
)

def _clean_text(val: str) -> str:
    """
    Clean text values by removing surrounding quotes and extra whitespace.
    
    Handles various quote types and ensures clean text output.
    
    Args:
        val: Input string to clean
        
    Returns:
        Cleaned string with quotes removed and whitespace trimmed
    """
    s = val.strip()
    if len(s) >= 2:
        # Check for matching quote pairs
        quote_pairs = [
            ('"', '"'),
            ("'", "'"),
            ("“", "”"),
            ("‘", "’")
        ]
        
        for open_quote, close_quote in quote_pairs:
            if s.startswith(open_quote) and s.endswith(close_quote):
                s = s[1:-1].strip()
                break
                
    return s

def _int_in(val: str) -> Optional[int]:
    """
    Extract integer value from a string.
    
    Args:
        val: Input string that may contain an integer
        
    Returns:
        Integer value if found and valid, None otherwise
    """
    m = re.search(r"(-?\d+)", val)
    if not m:
        return None
    
    try:
        return int(m.group(1))
    except Exception:
        return None

def _bool_in(val: str) -> Optional[bool]:
    """
    Extract boolean value from a string.
    
    Args:
        val: Input string that may represent a boolean
        
    Returns:
        Boolean value if recognized, None otherwise
    """
    val_lower = val.lower().strip()
    if val_lower in ("true", "yes", "1", "on"):
        return True
    elif val_lower in ("false", "no", "0", "off"):
        return False
    return None

def parse_proposer_lines(text: str) -> Dict[str, Any]:
    """
    Parse the proposer's LLM response into structured data.
    
    The proposer is expected to output lines in the format:
    key: value
    
    Where keys are: rationale, difficulty, verifiability, question
    
    This function is robust to:
    - Variations in whitespace
    - Different quote styles
    - Extra text before/after the key-value pairs
    - Case variations in keys
    
    Args:
        text: Raw LLM response from the proposer
        
    Returns:
        Dictionary with parsed values:
        - rationale: str (explanation for the question)
        - difficulty: int (0-100 scale)
        - verifiability: int (0-100 scale)
        - question: str (the generated question)
        - raw: str (original response)
        - ok: bool (whether parsing was successful)
    """
    raw = (text or " ").strip()
    out: Dict[str, Any] = {
        "rationale": "",
        "difficulty": 0,
        "verifiability": 0,
        "question": "",
        "raw": raw,
        "ok": False,
    }
    
    if not raw:
        return out
    
    # Process lines in reverse to handle multi-line values
    lines = [line.strip() for line in raw.splitlines() if line.strip()]
    found_keys = set()
    
    # First pass: identify key-value pairs
    for line in lines:
        match = _LINE_RE.match(line)
        if match:
            key = match.group("key").lower()
            value = match.group("value")
            
            if key == "rationale":
                out["rationale"] = _clean_text(value)
                found_keys.add("rationale")
            elif key == "difficulty":
                difficulty = _int_in(value)
                if difficulty is not None:
                    out["difficulty"] = max(0, min(100, difficulty))  # Clamp to 0-100
                    found_keys.add("difficulty")
            elif key == "verifiability":
                verifiability = _int_in(value)
                if verifiability is not None:
                    out["verifiability"] = max(0, min(100, verifiability))  # Clamp to 0-100
                    found_keys.add("verifiability")
            elif key == "question":
                out["question"] = _clean_text(value)
                found_keys.add("question")
    
    # Second pass: handle multi-line values if needed
    if "rationale" in found_keys and not out["rationale"]:
        # If rationale was identified but empty, check for multi-line rationale
        rationale_lines = []
        capturing = False
        
        for line in lines:
            if line.lower().startswith("rationale:"):
                capturing = True
                # Extract value after "rationale:"
                value = line[len("rationale:"):].strip()
                if value:
                    rationale_lines.append(_clean_text(value))
                continue
                
            if capturing:
                # Stop capturing when we hit the next known key
                if any(line.lower().startswith(f"{key}:") for key in 
                      ["difficulty", "verifiability", "question"]):
                    break
                rationale_lines.append(line)
        
        if rationale_lines:
            out["rationale"] = " ".join(rationale_lines).strip()
    
    # Validation - all required fields must be present
    required_keys = {"rationale", "difficulty", "verifiability", "question"}
    out["ok"] = required_keys.issubset(found_keys) and bool(out["question"].strip())
    
    return out

def parse_verifier_lines(text: str) -> Dict[str, Any]:
    """
    Parse the verifier's LLM response into structured data.
    
    Args:
        text: Raw LLM response from the verifier
        
    Returns:
        Dictionary with parsed values:
        - answer: str (predicted answer)
        - rationale: str (explanation for the answer)
        - score: float (verification score)
        - raw: str (original response)
        - ok: bool (whether parsing was successful)
    """
    raw = (text or " ").strip()
    out: Dict[str, Any] = {
        "answer": "",
        "rationale": "",
        "score": 0.0,
        "raw": raw,
        "ok": False,
    }
    
    if not raw:
        return out
    
    # Process lines to find key-value pairs
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
            
        # Look for answer line
        if line.lower().startswith("answer:"):
            out["answer"] = _clean_text(line[7:].strip())
        
        # Look for rationale line
        elif line.lower().startswith("rationale:"):
            out["rationale"] = _clean_text(line[10:].strip())
    
    # Determine if parsing was successful
    out["ok"] = bool(out["answer"].strip()) and bool(out["rationale"].strip())
    
    return out

def parse_solution_search_lines(text: str, top_k: int = 3) -> List[str]:
    """
    Parse the solution search LLM response into a list of evidence snippets.
    
    Args:
        text: Raw LLM response from solution search
        top_k: Number of expected snippets
        
    Returns:
        List of evidence snippets (up to top_k)
    """
    raw = (text or " ").strip()
    snippets = []
    
    if not raw:
        return snippets
    
    # Look for "snippet:" prefixes
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
            
        # Handle lines starting with "snippet:"
        if line.lower().startswith("snippet:"):
            snippet = _clean_text(line[8:].strip())
            if snippet:
                snippets.append(snippet)
    
    # If no "snippet:" prefixes found, try to split by line numbers or bullet points
    if not snippets:
        # Look for numbered lines (1., 2., etc.)
        numbered_lines = re.findall(r"^\s*\d+\.\s+(.+)$", raw, re.MULTILINE)
        if numbered_lines:
            snippets = [_clean_text(line) for line in numbered_lines[:top_k]]
        
        # Look for bullet points
        elif not snippets:
            bullet_lines = re.findall(r"^\s*[-*•]\s+(.+)$", raw, re.MULTILINE)
            if bullet_lines:
                snippets = [_clean_text(line) for line in bullet_lines[:top_k]]
    
    # If still no snippets, try to split into reasonable chunks
    if not snippets:
        # Split by sentence boundaries if it looks like a paragraph
        if len(raw.split()) > 10 and "." in raw:
            sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", raw) if s.strip()]
            snippets = sentences[:top_k]
    
    return snippets[:top_k]  # Ensure we don't return more than top_k snippets
``n

## File: utils\trace.py

`python
"""
Episode Trace Data Structure

This module defines the EpisodeTrace class that captures the
complete state of an SSP episode, including all critical
information needed for self-play rewards and VPM visualization.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class EpisodeTrace:
    """Complete trace of an SSP episode for analysis and visualization."""
    
    episode_id: str
    seed_answer: str
    question: str
    proposer_evidence: List[str]
    predicted_answer: str
    evidence_docs: List[str]
    verified: bool
    verifier_score: float
    solver_steps: int
    difficulty: float = 0.0
    proposer_meta: Dict[str, Any] = field(default_factory=dict)
    verifier_meta: Dict[str, Any] = field(default_factory=dict)
    solver_meta: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    episode_duration: float = 0.0
    proposer_reward: Optional[float] = None
    solver_reward: Optional[float] = None
``n
