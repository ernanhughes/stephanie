"""
AI Co-Scientist Package

A modular pipeline for hypothesis generation, evaluation, and summarization using DSPy, pgvector, and Ollama.
"""
__version__ = "0.1.0"
