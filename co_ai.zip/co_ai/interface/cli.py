# co_ai/interface/cli.py

def get_user_goal() -> str:
    return input("Enter your research goal: ").strip()
