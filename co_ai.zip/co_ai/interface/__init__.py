"""User interaction modules (e.g., CLI input)"""
from .cli import get_user_goal
