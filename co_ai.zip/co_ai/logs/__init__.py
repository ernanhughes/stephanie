"""Dataclasses and utilities for logging"""
from .json_logger import JSONLogger
from .ranking_log import EloRankingLog
