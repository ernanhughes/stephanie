# co_ai/agents/generation.py
from dspy import Predict, Signature, InputField, OutputField
from dspy import LM

from co_ai.agents.base import BaseAgent
from co_ai.memory.hypothesis_model import Hypothesis

class GenerateSignature(Signature):
    """Generate a list of research hypotheses given a specific goal."""
    goal = InputField()
    hypotheses = OutputField()

class GenerationAgent(BaseAgent):
    def __init__(self, memory=None, logger=None, model_config=None):
        super().__init__(memory=memory, logger=logger)
        self.model_config = model_config or {
            "name": "ollama_chat/qwen2.5",
            "api_base": "http://localhost:11434",
            "api_key": None,
        }
        lm = LM(
            self.model_config["name"],
            api_base=self.model_config["api_base"],
            api_key=self.model_config.get("api_key")
        )
        self.generator = Predict(GenerateSignature, lm=lm)

    async def run(self, input_data: dict) -> dict:
        goal = input_data.get("goal")
        self.log(f"Generating hypotheses for goal: {goal}")
        result = self.generator(goal=goal)

        hypotheses = [h.strip() for h in result.hypotheses.split("\n") if h.strip()]
        self.log(f"Generated {len(hypotheses)} hypotheses.")

        hypothesis_objs = []
        for h in hypotheses:
            hyp = Hypothesis(goal=goal, text=h)
            self.memory.store_hypothesis(hyp)
            hypothesis_objs.append(hyp)

        return {"hypotheses": hypothesis_objs}
